import React, { useState, useEffect } from 'react';
import { 
  FileHeart, LayoutDashboard, UserCheck, ClipboardList, TableProperties, FileBarChart, RefreshCw, LogOut, HeartHandshake, Menu, X, Users, Settings2
} from 'lucide-react';
import { MasterAnggota, Attendance, PemeriksaanBalita, PemeriksaanKategoriLain, LoginLog, SyncConfig } from './types';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import AbsenInput from './components/AbsenInput';
import PemeriksaanInput from './components/PemeriksaanInput';
import DataTabel from './components/DataTabel';
import LaporanMonthly from './components/LaporanMonthly';
import SyncSettings from './components/SyncSettings';

// Preloaded realistic Master Anggota
const INITIAL_MASTER_ANGGOTA: MasterAnggota[] = [
  { kodeUnik: 'BLA-MIN1', kategori: 'BALITA', nama: 'Ariyani Lestari', nik: '3324056108250001', jenisKelamin: 'P', tglLahir: '2025-08-16', namaOrtu: 'Sugeng & Rini', posyandu: 'MINERAL 1', alamat: 'Slobor RT 02/01' },
  { kodeUnik: 'BML-MAW1', kategori: 'IBUHAMIL', nama: 'Endang Purwati', nik: '3324054412950002', jenisKelamin: 'P', tglLahir: '1995-12-04', namaOrtu: '', posyandu: 'MAWAR', alamat: 'Kalikesek RT 01/02' },
  { kodeUnik: 'LAN-SJH1', kategori: 'LANSIA', nama: 'Mbah Karto Joyo', nik: '3324050203580003', jenisKelamin: 'L', tglLahir: '1958-03-02', namaOrtu: '', posyandu: 'SEJAHTERA', alamat: 'Nglimut RT 04/02' },
  { kodeUnik: 'KDR-MAW1', kategori: 'KADER', nama: 'Setyani', nik: '3324055204920004', jenisKelamin: 'P', tglLahir: '1992-04-12', namaOrtu: '', posyandu: 'MAWAR', alamat: 'Slobor RT 03/01' },
  { kodeUnik: 'RMJ-PRO1', kategori: 'REMAJA', nama: 'Rani Rahmawati', nik: '3324054810110005', jenisKelamin: 'P', tglLahir: '2011-10-08', namaOrtu: '', posyandu: 'PROTEIN', alamat: 'Gonoharjo RT 01/01' },
  { kodeUnik: 'PDT-VIT1', kategori: 'USIAPRODUKTIF', nama: 'Bambang Triyono', nik: '3324051511870006', jenisKelamin: 'L', tglLahir: '1987-11-15', namaOrtu: '', posyandu: 'VITAMIN', alamat: 'Kalikesek RT 02/03' },
];

const INITIAL_ATTENDANCE: Attendance[] = [
  { id: 'ATT-1', tanggal: '2026-05-29', nama: 'Ariyani Lestari', kodeUnik: 'BLA-MIN1', kategori: 'BALITA', posyandu: 'MINERAL 1', status: 'Hadir' },
  { id: 'ATT-2', tanggal: '2026-05-29', nama: 'Endang Purwati', kodeUnik: 'BML-MAW1', kategori: 'IBUHAMIL', posyandu: 'MAWAR', status: 'Hadir' },
  { id: 'ATT-3', tanggal: '2026-05-29', nama: 'Mbah Karto Joyo', kodeUnik: 'LAN-SJH1', kategori: 'LANSIA', posyandu: 'SEJAHTERA', status: 'Hadir' },
];

const INITIAL_PEMERIKSAAN_BALITA: PemeriksaanBalita[] = [
  {
    id: 'EXB-1',
    tanggalInput: '2026-05-29',
    tanggalEdit: null,
    nama: 'Ariyani Lestari',
    namaOrtu: 'Sugeng & Rini',
    posyandu: 'MINERAL 1',
    beratBadan: 9.2,
    tinggiBadan: 78.5,
    lila: 12.5,
    lingkarKepala: 46,
    bbU: 'NORMAL',
    pbTbU: 'NORMAL',
    bbPbTb: 'GIZI BAIK',
    statusNTO: 'N',
    catatan: 'Pertumbuhan sehat, vitamin A sudah diberikan.',
    namaPenginput: 'Bdn. Sri Wahyuni',
    namaPengedit: null
  }
];

const INITIAL_PEMERIKSAAN_LAIN: PemeriksaanKategoriLain[] = [
  {
    id: 'EXL-1',
    tanggalInput: '2026-05-29',
    tanggalEdit: null,
    nama: 'Endang Purwati',
    kategori: 'IBUHAMIL',
    posyandu: 'MAWAR',
    bb: 58.5,
    tb: 156,
    lingkarPerut: 0,
    lila: 25.2,
    tekananDarah: '110/80',
    gulaDarah: 'Habis',
    asamUrat: '90',
    kolesterol: 'Alat Kosong',
    catatan: 'Keadaaan ibu hamil baik, mual pagi berkurang.',
    namaPenginput: 'Setyani',
    namaPengedit: null
  },
  {
    id: 'EXL-2',
    tanggalInput: '2026-05-29',
    tanggalEdit: null,
    nama: 'Mbah Karto Joyo',
    kategori: 'LANSIA',
    posyandu: 'SEJAHTERA',
    bb: 56,
    tb: 161,
    lingkarPerut: 82,
    lila: 0,
    tekananDarah: '142/90',
    gulaDarah: '118',
    asamUrat: 'Alat Kosong',
    kolesterol: 'Habis',
    catatan: 'Linu persendian diberi kalsium.',
    namaPenginput: 'Bdn. Sri Wahyuni',
    namaPengedit: null
  }
];

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem('posyandu_session') || null;
  });

  const [loginHistory, setLoginHistory] = useState<LoginLog[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_login_logs');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing login history:', e);
    }
    return [];
  });

  const [admins, setAdmins] = useState<any[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_admins');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing admins:', e);
    }
    return [
      { username: 'admin', password: 'gonoharjo2026', nama: 'Bdn. Sri Wahyuni', peran: 'Bidan', bisaTambahMaster: true },
      { username: 'petugas', password: 'posyandu', nama: 'Setyani', peran: 'Kader', bisaTambahMaster: false }
    ];
  });

  // Base persistent state declarations matching 3 sheets concept
  const [masterAnggota, setMasterAnggota] = useState<MasterAnggota[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_master_anggota');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing master anggota:', e);
    }
    return INITIAL_MASTER_ANGGOTA;
  });

  const [attendances, setAttendances] = useState<Attendance[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_attendances');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing attendances:', e);
    }
    return INITIAL_ATTENDANCE;
  });

  const [pemeriksaanBalita, setPemeriksaanBalita] = useState<PemeriksaanBalita[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_pemeriksaan_balita');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing pemeriksaan balita:', e);
    }
    return INITIAL_PEMERIKSAAN_BALITA;
  });

  const [pemeriksaanLain, setPemeriksaanLain] = useState<PemeriksaanKategoriLain[]>(() => {
    try {
      const raw = localStorage.getItem('posyandu_pemeriksaan_lain');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error parsing pemeriksaan lain:', e);
    }
    return INITIAL_PEMERIKSAAN_LAIN;
  });

  const [syncConfig, setSyncConfig] = useState<SyncConfig>(() => {
    const raw = localStorage.getItem('posyandu_sync_config');
    return raw ? JSON.parse(raw) : {
      appsScriptUrl: '',
      lastSyncedAt: null,
      autoSync: false
    };
  });

  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedAttendeeForExam, setSelectedAttendeeForExam] = useState<string | undefined>(undefined);

  // Sync to database disk automatically
  useEffect(() => {
    localStorage.setItem('posyandu_master_anggota', JSON.stringify(masterAnggota));
  }, [masterAnggota]);

  useEffect(() => {
    localStorage.setItem('posyandu_attendances', JSON.stringify(attendances));
  }, [attendances]);

  useEffect(() => {
    localStorage.setItem('posyandu_pemeriksaan_balita', JSON.stringify(pemeriksaanBalita));
  }, [pemeriksaanBalita]);

  useEffect(() => {
    localStorage.setItem('posyandu_pemeriksaan_lain', JSON.stringify(pemeriksaanLain));
  }, [pemeriksaanLain]);

  useEffect(() => {
    localStorage.setItem('posyandu_login_logs', JSON.stringify(loginHistory));
  }, [loginHistory]);

  useEffect(() => {
    localStorage.setItem('posyandu_sync_config', JSON.stringify(syncConfig));
  }, [syncConfig]);

  useEffect(() => {
    localStorage.setItem('posyandu_admins', JSON.stringify(admins));
  }, [admins]);

  // Auth operations
  const handleLoginSuccess = (username: string) => {
    setCurrentUser(username);
    localStorage.setItem('posyandu_session', username);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('posyandu_session');
  };

  const addLoginLog = (log: LoginLog) => {
    setLoginHistory((prev) => [log, ...prev.slice(0, 19)]);
  };

  // Master Anggota Ops
  const addMasterAnggota = (newItem: MasterAnggota) => {
    setMasterAnggota((prev) => [...prev, newItem]);
  };

  const deleteMasterAnggota = (kodeUnik: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus Anggota dengan KODEUNIK: ${kodeUnik}?`)) {
      setMasterAnggota((prev) => prev.filter((item) => item.kodeUnik !== kodeUnik));
    }
  };

  const updateMasterAnggota = (updated: MasterAnggota) => {
    setMasterAnggota((prev) => prev.map((item) => item.kodeUnik === updated.kodeUnik ? updated : item));
  };

  // Attendance Ops
  const addAttendance = (att: Attendance) => {
    setAttendances((prev) => [att, ...prev]);
  };

  const deleteAttendance = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data absensi ini?')) {
      setAttendances((prev) => prev.filter((item) => item.id !== id));
    }
  };

  // Examination Ops
  const addPemeriksaanBalita = (exam: PemeriksaanBalita) => {
    setPemeriksaanBalita((prev) => [exam, ...prev]);
  };

  const deletePemeriksaanBalita = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data pemeriksaan Balita ini?')) {
      setPemeriksaanBalita((prev) => prev.filter((item) => item.id !== id));
    }
  };

  const updatePemeriksaanBalita = (updated: PemeriksaanBalita) => {
    setPemeriksaanBalita((prev) => prev.map((item) => item.id === updated.id ? updated : item));
  };

  const addPemeriksaanLain = (exam: PemeriksaanKategoriLain) => {
    setPemeriksaanLain((prev) => [exam, ...prev]);
  };

  const deletePemeriksaanLain = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data pemeriksaan ini?')) {
      setPemeriksaanLain((prev) => prev.filter((item) => item.id !== id));
    }
  };

  const updatePemeriksaanLain = (updated: PemeriksaanKategoriLain) => {
    setPemeriksaanLain((prev) => prev.map((item) => item.id === updated.id ? updated : item));
  };

  // Sheets sync mechanics - 3 Sheets schema mapping
  const pullDataFromSheets = async () => {
    if (!syncConfig.appsScriptUrl) {
      throw new Error('Alamat URL Google Apps Script Web App belum dikonfigurasi.');
    }

    const response = await fetch(syncConfig.appsScriptUrl + '?action=pull', {
      method: 'GET',
      mode: 'cors'
    });

    if (!response.ok) {
      throw new Error(`Koneksi HTTP bermasalah: ${response.status}`);
    }

    const data = await response.json();
    if (data.masterAnggota) {
      setMasterAnggota(data.masterAnggota);
    }
    if (data.dataAdmin) {
      setAdmins(data.dataAdmin);
    }
    if (data.attendances) {
      setAttendances(data.attendances);
    }
    if (data.pemeriksaanBalita) {
      setPemeriksaanBalita(data.pemeriksaanBalita);
    }
    if (data.pemeriksaanLain) {
      setPemeriksaanLain(data.pemeriksaanLain);
    }

    setSyncConfig(prev => ({
      ...prev,
      lastSyncedAt: new Date().toLocaleString('id-ID')
    }));
  };

  const pushDataToSheets = async () => {
    if (!syncConfig.appsScriptUrl) {
      throw new Error('Alamat URL Google Apps Script Web App belum dikonfigurasi.');
    }

    const payload = {
      masterAnggota: masterAnggota,
      dataAdmin: admins,
      attendances: attendances,
      pemeriksaanBalita: pemeriksaanBalita,
      pemeriksaanLain: pemeriksaanLain
    };

    const response = await fetch(syncConfig.appsScriptUrl, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Koneksi HTTP bermasalah: ${response.status}`);
    }

    const resJson = await response.json();
    if (resJson.status === 'error') {
      throw new Error(`Google Script Error: ${resJson.error}`);
    }

    setSyncConfig(prev => ({
      ...prev,
      lastSyncedAt: new Date().toLocaleString('id-ID')
    }));
  };

  const navigateToTab = (tab: string) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  if (!currentUser) {
    return (
      <Login 
        onLoginSuccess={handleLoginSuccess}
        loginHistory={loginHistory}
        onAddLoginLog={addLoginLog}
        admins={admins}
        onRegisterAdmin={(newAdmin) => {
          setAdmins((prev) => [...prev, newAdmin]);
        }}
      />
    );
  }

  // Active Admin object details
  const loggedInAdmin = Array.isArray(admins) 
    ? (admins.find(a => a && a.username && a.username.toString().toLowerCase() === currentUser?.toLowerCase()) || null)
    : null;
  const currentAdminName = loggedInAdmin ? loggedInAdmin.nama : (currentUser === 'admin' ? 'Bdn. Sri Wahyuni' : 'Setyani');
  const currentAdminPeran = loggedInAdmin ? loggedInAdmin.peran : (currentUser === 'admin' ? 'Bidan' : 'Kader');
  const canAddMaster = loggedInAdmin 
    ? (loggedInAdmin.bisaTambahMaster === 'true' || loggedInAdmin.bisaTambahMaster === true || String(loggedInAdmin.bisaTambahMaster).toLowerCase() === 'true' || loggedInAdmin.peran === 'Bidan')
    : (currentUser === 'admin');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Top Header Row (Hidden during printing) */}
      <header className="no-print bg-white border-b border-slate-155 sticky top-0 z-45 px-4 sm:px-6 py-3 flex justify-between items-center">
        <div className="flex flex-col">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 sm:w-9 sm:h-9 shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Circle outline */}
                <circle cx="50" cy="50" r="46" stroke="#9333ea" strokeWidth="2.5" fill="white" />
                
                {/* Top Orange Person */}
                <circle cx="50" cy="27" r="5" fill="#f97316" />
                <path d="M 34,34 Q 50,49 66,34" stroke="#f97316" strokeWidth="7" strokeLinecap="round" />

                {/* Left Cyan Person */}
                <circle cx="20" cy="30" r="5" fill="#06b6d4" />
                <path d="M 33,39 Q 19,42 27,60" stroke="#06b6d4" strokeWidth="7" strokeLinecap="round" />

                {/* Right Pink Person */}
                <circle cx="80" cy="30" r="5" fill="#d946ef" />
                <path d="M 67,39 Q 81,42 73,60" stroke="#d946ef" strokeWidth="7" strokeLinecap="round" />

                {/* Bottom Green Person */}
                <circle cx="50" cy="62" r="5" fill="#22c55e" />
                <path d="M 34,66 Q 50,81 66,66" stroke="#22c55e" strokeWidth="7" strokeLinecap="round" />
              </svg>
            </div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm sm:text-base font-black tracking-tight text-slate-900 uppercase font-sans">
                GO-POSITIF
              </h1>
              <span className="text-[9px] bg-violet-100 text-violet-700 px-1.5 py-0.5 rounded font-mono font-bold">3-SHEETS V3.0</span>
            </div>
          </div>
          <p className="text-[9px] sm:text-[10px] text-slate-500 font-extrabold uppercase tracking-wider font-sans mt-1.5 pl-0.5">
            GONOHARJO POSYANDU ILP AKTIF
          </p>
        </div>

        {/* User bar & Actions */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-slate-800">{currentAdminName}</span>
            <span className="text-[9px] text-violet-650 bg-violet-50 px-1.5 py-0.5 rounded-full inline-block mt-0.5 font-bold font-mono uppercase tracking-wider">
              {currentAdminPeran === 'Bidan' ? 'Administrator' : 'Kader Tugas'}
            </span>
          </div>

          <button
            id="btn-logout-main"
            onClick={handleLogout}
            className="p-1.5 px-3.5 border border-slate-200 rounded-xl text-xs hover:bg-slate-50 font-bold cursor-pointer text-slate-600 flex items-center gap-1.5 transition-colors"
          >
            <LogOut size={13} />
            Keluar
          </button>

          {/* Hamburger (Mobile navigation toggle) */}
          <button
            id="mobile-nav-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 hover:bg-slate-50 text-slate-600 rounded-lg cursor-pointer"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {/* Main Core Section */}
      <div className="flex-1 flex flex-col lg:flex-row relative">
        
        {/* Navigation Sidebar Drawer (Hidden when printing) */}
        <nav className={`no-print w-full lg:w-64 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 shrink-0 p-4 space-y-1.5 transition-all z-35 ${
          mobileMenuOpen ? 'block' : 'hidden lg:block'
        }`}>
          <div className="text-[10px] font-bold text-slate-450 uppercase tracking-widest px-3 mb-2 font-mono">
            Menu Utama Aplikasi
          </div>

          {[
            { id: 'dashboard', label: 'Dashboard Utama', icon: LayoutDashboard },
            { id: 'master-anggota', label: 'Master Anggota', icon: Users },
            { id: 'input-absen', label: 'Input Absensi', icon: UserCheck },
            { id: 'input-pemeriksaan', label: 'Input Pemeriksaan', icon: ClipboardList },
            { id: 'tabel-grafik', label: 'Tabel Data (3 Sheets)', icon: TableProperties },
            { id: 'laporan', label: 'Tab Extrak Laporan', icon: FileBarChart },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSel = activeTab === tab.id;
            return (
              <button
                id={`sidebar-link-${tab.id}`}
                key={tab.id}
                onClick={() => navigateToTab(tab.id)}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2.5 ${
                  isSel 
                    ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-sm font-extrabold' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}

          <div className="text-[10px] font-bold text-slate-450 uppercase tracking-widest px-3 pt-6 mb-2 font-mono">
            Integrasi Backend
          </div>
          
          <button
            id="sidebar-link-sync-settings"
            onClick={() => navigateToTab('sync-settings')}
            className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
              activeTab === 'sync-settings' 
                ? 'bg-slate-900 text-white shadow' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Settings2 size={15} />
              Setelan Google Sheets
            </span>
            {syncConfig.appsScriptUrl ? (
              <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />
            ) : (
              <span className="w-1.5 h-1.5 rounded-full bg-slate-350" />
            )}
          </button>

          {/* Quick Info box inside side frame */}
          <div className="p-3.5 bg-violet-50/50 border border-violet-100 rounded-xl mt-6 shadow-sm">
            <h4 className="text-[10px] font-bold text-violet-900 flex items-center justify-between gap-1.5 mb-1 font-sans">
              <span className="flex items-center gap-1 font-mono">
                <HeartHandshake size={11} className="text-violet-600" />
                INFO PROTOKOL
              </span>
            </h4>
            <p className="text-[10px] text-slate-500 leading-normal font-medium">
              Alur Wajib: <br/>
              <b>1. Tambah Anggota</b> jika sasaran baru <br/>
              <b>2. Check-in Absen</b> Hari ini <br/>
              <b>3. Input Pemeriksaan</b> Medis
            </p>
          </div>
        </nav>

        {/* Dynamic Display Panel */}
        <main className="flex-1 p-4 sm:p-6 md:p-8 max-w-7xl mx-auto w-full overflow-y-auto">
          {activeTab === 'dashboard' && (
            <Dashboard 
              masterAnggota={masterAnggota}
              attendances={attendances}
              pemeriksaanBalita={pemeriksaanBalita}
              pemeriksaanLain={pemeriksaanLain}
              onNavigate={navigateToTab}
            />
          )}

          {activeTab === 'master-anggota' && (
            <div className="max-w-5xl mx-auto bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 pb-4 mb-6">
                <div>
                  <h2 className="text-base font-extrabold text-slate-800 flex items-center gap-1.5 font-sans">
                    <Users size={20} className="text-violet-600" />
                    Manajemen & Tambah Master Anggota
                  </h2>
                  <p className="text-xs text-slate-400">Daftarkan dan edit data master anggota sasaran posyandu untuk generate KODEUNIK</p>
                </div>
              </div>
              <AbsenInput 
                isMasterOnly={true}
                masterAnggota={masterAnggota}
                onAddMasterAnggota={addMasterAnggota}
                onDeleteMasterAnggota={deleteMasterAnggota}
                onUpdateMasterAnggota={updateMasterAnggota}
                canAddMaster={canAddMaster}
                currentUser={currentAdminName}
              />
            </div>
          )}

          {activeTab === 'input-absen' && (
            <div className="max-w-5xl mx-auto bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <div className="border-b border-slate-50 pb-4 mb-6">
                <h2 className="text-base font-extrabold text-slate-800 flex items-center gap-1.5 font-sans">
                  <UserCheck size={20} className="text-violet-600" />
                  Presensi / Absensi Hadir Hari Ini
                </h2>
                <p className="text-xs text-slate-400">Lakukan check-in kehadiran menggunakan 4 metode: Kode Unik, Scan Live, Photo, atau Upload</p>
              </div>
              <AbsenInput 
                isMasterOnly={false}
                masterAnggota={masterAnggota}
                attendances={attendances}
                onAddAttendance={addAttendance}
                onDeleteAttendance={deleteAttendance}
                onNavigateToTab={navigateToTab}
                canAddMaster={canAddMaster}
                currentUser={currentAdminName}
              />
            </div>
          )}

          {activeTab === 'input-pemeriksaan' && (
            <PemeriksaanInput 
              masterAnggota={masterAnggota}
              attendances={attendances}
              onAddAttendance={addAttendance}
              onAddPemeriksaanBalita={addPemeriksaanBalita}
              onAddPemeriksaanLain={addPemeriksaanLain}
              selectedAttendeeCode={selectedAttendeeForExam}
              clearSelectedAttendeeCode={() => setSelectedAttendeeForExam(undefined)}
              currentUser={currentAdminName}
              onNavigateToTab={navigateToTab}
            />
          )}

          {activeTab === 'tabel-grafik' && (
            <DataTabel 
              masterAnggota={masterAnggota}
              attendances={attendances}
              pemeriksaanBalita={pemeriksaanBalita}
              pemeriksaanLain={pemeriksaanLain}
              onDeleteMasterAnggota={deleteMasterAnggota}
              onDeleteAttendance={deleteAttendance}
              onDeletePemeriksaanBalita={deletePemeriksaanBalita}
              onDeletePemeriksaanLain={deletePemeriksaanLain}
              onUpdateMasterAnggota={updateMasterAnggota}
              onUpdatePemeriksaanBalita={updatePemeriksaanBalita}
              onUpdatePemeriksaanLain={updatePemeriksaanLain}
            />
          )}

          {activeTab === 'laporan' && (
            <LaporanMonthly 
              attendances={attendances}
              pemeriksaanBalita={pemeriksaanBalita}
              pemeriksaanLain={pemeriksaanLain}
            />
          )}

          {activeTab === 'sync-settings' && (
            <SyncSettings 
              config={syncConfig}
              onUpdateConfig={setSyncConfig}
              onPullData={pullDataFromSheets}
              onPushData={pushDataToSheets}
            />
          )}
        </main>

      </div>

      {/* Global Footer Copyright Disclaimer */}
      <footer className="no-print w-full py-4 border-t border-slate-200 bg-white text-center shrink-0">
        <p className="text-slate-500 text-[10px] font-black tracking-widest uppercase font-mono text-center">
          Copyright © 2026 L. All Rights Reserved
        </p>
      </footer>

    </div>
  );
}
