import React from 'react';
import { 
  Users, Baby, Sparkles, Heart, Activity, Milestone, Clock, CheckCircle2, FileSpreadsheet, ArrowUpRight, Plus, MapPin 
} from 'lucide-react';
import { MasterAnggota, Attendance, PemeriksaanBalita, PemeriksaanKategoriLain } from '../types';

interface DashboardProps {
  masterAnggota: MasterAnggota[];
  attendances: Attendance[];
  pemeriksaanBalita: PemeriksaanBalita[];
  pemeriksaanLain: PemeriksaanKategoriLain[];
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ 
  masterAnggota, 
  attendances, 
  pemeriksaanBalita, 
  pemeriksaanLain, 
  onNavigate 
}: DashboardProps) {

  // Count by category
  const countStats = {
    KADER: pemeriksaanLain.filter(l => l.kategori === 'KADER').length,
    BALITA: pemeriksaanBalita.length,
    REMAJA: pemeriksaanLain.filter(l => l.kategori === 'REMAJA').length,
    IBUHAMIL: pemeriksaanLain.filter(l => l.kategori === 'IBUHAMIL').length,
    USIAPRODUKTIF: pemeriksaanLain.filter(l => l.kategori === 'USIAPRODUKTIF').length,
    LANSIA: pemeriksaanLain.filter(l => l.kategori === 'LANSIA').length,
  };

  const totalRegistered = pemeriksaanBalita.length + pemeriksaanLain.length;
  
  const todayStr = new Date().toISOString().split('T')[0];
  const todayAttendance = attendances.filter(a => a.tanggal === todayStr).length;

  const hadirPercentage = attendances.length > 0 ? 100 : 100; // As all entries are checkout,attendance is 100% of check-in base

  // Demographics stats
  const rolesData = [
    { name: 'Kader', value: countStats.KADER, color: '#f59e0b' },
    { name: 'Balita', value: countStats.BALITA, color: '#10b981' },
    { name: 'Remaja', value: countStats.REMAJA, color: '#3b82f6' },
    { name: 'Ibu Hamil', value: countStats.IBUHAMIL, color: '#ec4899' },
    { name: 'Usia Prod', value: countStats.USIAPRODUKTIF, color: '#8b5cf6' },
    { name: 'Lansia', value: countStats.LANSIA, color: '#64748b' },
  ];

  // Posyandu data calculation from Master Anggota as the population cohort base
  const posyanduList = ['MINERAL 1', 'MINERAL 2', 'MAWAR', 'SEJAHTERA', 'PROTEIN', 'VITAMIN'];
  const posyanduData = posyanduList.map(posy => {
    const total = masterAnggota.filter(m => m.posyandu === posy).length;
    return { name: posy, value: total };
  });

  const maxPosyanduValue = Math.max(...posyanduData.map(d => d.value), 1);

  // Merge & slice recent activities
  const recentHistories = (() => {
    const list: Array<{ id: string; nama: string; peran: string; tanggal: string; petugas: string; detail: string }> = [];

    pemeriksaanBalita.forEach(b => {
      list.push({
        id: b.id,
        nama: b.nama,
        peran: 'BALITA',
        tanggal: b.tanggalInput,
        petugas: b.namaPenginput,
        detail: `BB ${b.beratBadan}kg / TB ${b.tinggiBadan}cm (Gizi ${b.bbPbTb})`
      });
    });

    pemeriksaanLain.forEach(l => {
      list.push({
        id: l.id,
        nama: l.nama,
        peran: l.kategori,
        tanggal: l.tanggalInput,
        petugas: l.namaPenginput,
        detail: `TD ${l.tekananDarah} / Gula ${l.gulaDarah}`
      });
    });

    // Sort by date/id descending
    return list.sort((a,b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 4);
  })();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 rounded-2xl p-6 md:p-8 text-white shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        <div className="absolute left-1/3 bottom-0 w-32 h-32 bg-indigo-400/10 rounded-full blur-xl"></div>
        
        <div className="relative z-10 max-w-xl">
          <span className="bg-white/10 text-white text-xs px-3 py-1 rounded-full font-bold border border-white/10 uppercase tracking-wider backdrop-blur-sm">
            Portal Administrasi Desa Terpadu
          </span>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight mt-3">
            POSYANDU DESA GONOHARJO
          </h1>
          <p className="text-violet-50 mt-2 text-xs md:text-sm leading-relaxed font-medium">
            Selamat datang di sistem manajemen kearsipan & pelaporan POSYANDU GONOHARJO.
          </p>
          <div className="mt-5 flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigate('input-absen')}
              className="px-4 py-2 bg-white text-violet-700 rounded-xl font-bold text-xs cursor-pointer hover:bg-violet-50 transition-all flex items-center gap-1.5 shadow"
            >
              <Plus size={14} /> Check-in Absensi
            </button>
            <button
              onClick={() => onNavigate('laporan')}
              className="px-4 py-2 bg-violet-500 hover:bg-violet-400 text-white rounded-xl font-bold text-xs cursor-pointer transition-all flex items-center gap-1.5 border border-violet-400/30"
            >
              <FileSpreadsheet size={14} /> Cetak Laporan Posyandu
            </button>
          </div>
        </div>
      </div>

      {/* Numerical Metrics Grid */}
      <h2 className="text-xs font-bold text-slate-450 tracking-widest uppercase mb-[-12px] flex items-center gap-2 font-mono">
        <Milestone size={14} className="text-violet-500" />
        Status Rekapitulasi Klinik Aktif
      </h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        
        {/* Balita */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-violet-200 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-violet-50 text-violet-600 flex items-center justify-center">
            <Baby size={18} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">BALITA</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.BALITA}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>

        {/* Ibu Hamil */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-pink-200 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-pink-50 text-pink-600 flex items-center justify-center">
            <Activity size={18} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ibu Hamil</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.IBUHAMIL}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>

        {/* Lansia */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-slate-300 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center">
            <Heart size={18} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">LANSIA</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.LANSIA}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>

        {/* Remaja */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Sparkles size={16} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">REMAJA</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.REMAJA}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>

        {/* Usia Produktif */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-purple-200 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
            <Users size={16} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">USIA PROD</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.USIAPRODUKTIF}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>

        {/* Kader */}
        <div 
          onClick={() => onNavigate('input-pemeriksaan')}
          className="bg-white p-4 rounded-xl border border-slate-100 hover:border-amber-200 hover:shadow-sm cursor-pointer transition relative overflow-hidden flex flex-col justify-between h-28"
        >
          <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <Users size={16} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">KADER</p>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-lg font-black text-slate-800">{countStats.KADER}</span>
              <span className="text-[9px] text-slate-400">Kasus</span>
            </div>
          </div>
          <span className="absolute right-3 top-3 text-slate-350">
            <ArrowUpRight size={14} />
          </span>
        </div>
      </div>

      {/* Visual Charts Layout using direct responsive SVG */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Pie / Donut Chart Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-black text-slate-800 tracking-wide uppercase font-mono">Proporsi Demografi Pemeriksaan</h3>
            <p className="text-[11px] text-slate-450 mb-4">Grafik lingkaran representasi rekam medis aktif</p>
          </div>

          <div className="flex flex-col items-center justify-center py-2 h-full">
            {totalRegistered === 0 ? (
              <div className="flex flex-col items-center justify-center text-slate-300 text-xs text-center py-8">
                <FileSpreadsheet size={24} className="mb-2" />
                Belum ada rekam medis diinputkan hari ini.
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 w-full">
                
                {/* SVG Semi-animated Donut Chart */}
                <div className="relative w-32 h-32 shrink-0">
                  <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                    <circle cx="50" cy="50" r="40" fill="none" stroke="#f1f5f9" strokeWidth="12" />
                    {(() => {
                      let currentOffset = 0;
                      return rolesData.map((item, idx) => {
                        const val = item.value;
                        if (val === 0) return null;
                        const pct = (val / totalRegistered) * 100;
                        const dashArray = `${(pct * 251.2) / 100} 251.2`;
                        const dashOffset = `-${(currentOffset * 251.2) / 100}`;
                        currentOffset += pct;
                        return (
                          <circle
                            key={idx}
                            cx="50"
                            cy="50"
                            r="40"
                            fill="none"
                            stroke={item.color}
                            strokeWidth="12"
                            strokeDasharray={dashArray}
                            strokeDashoffset={dashOffset}
                            className="transition-all duration-300"
                          />
                        );
                      });
                    })()}
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-base font-black text-slate-800">{totalRegistered}</span>
                    <span className="text-[8px] text-slate-400 uppercase tracking-widest font-black">Total</span>
                  </div>
                </div>

                {/* Donut Legend */}
                <div className="space-y-1 text-[11px] w-full font-semibold">
                  {rolesData.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                      <span className="text-slate-500 truncate">{item.name}</span>
                      <span className="font-extrabold text-slate-800 ml-auto font-mono">
                        {item.value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bar Chart for Posyandu Distribution */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-black text-slate-800 tracking-wide uppercase font-mono">SEBARAN BERDASAR POSYANDU</h3>
            <p className="text-[11px] text-slate-450 mb-4">Sensus kelompok posyandu dari Master Anggota saat ini</p>
          </div>

          <div className="space-y-3 py-2">
            {posyanduData.map((posy, idx) => {
              const pct = (posy.value / maxPosyanduValue) * 100;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between items-center text-xs font-bold font-mono">
                    <span className="text-slate-600 flex items-center gap-1 uppercase">
                      <MapPin size={11} className="text-slate-400" />
                      {posy.name}
                    </span>
                    <span className="text-slate-800">{posy.value} Anggota</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full bg-gradient-to-r from-violet-500 to-indigo-500"
                      style={{ width: `${Math.max(pct, 2)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-slate-50 pt-2.5 flex justify-end">
            <span className="text-[10px] text-violet-600 font-extrabold cursor-pointer hover:underline" onClick={() => onNavigate('tabel-grafik')}>
              Lihat database penuh →
            </span>
          </div>
        </div>

        {/* Absensi & Activity Summary Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-black text-slate-800 tracking-wide uppercase font-mono">Kehadiran Hari Ini</h3>
            <p className="text-[11px] text-slate-450 mb-4 font-mono">Check-ins hari ini ({todayStr})</p>
          </div>

          <div className="space-y-3.5 py-1">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center gap-3">
              <div className="p-2 bg-violet-50 text-violet-600 rounded-lg">
                <Clock size={18} />
              </div>
              <div>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">Masuk Absen</p>
                <p className="text-base font-black text-slate-800">{todayAttendance} Orang Hadir</p>
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <CheckCircle2 size={18} />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-baseline mb-0.5 text-xs">
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">Kehadiran Total (%)</p>
                  <p className="font-extrabold text-indigo-600">{hadirPercentage}%</p>
                </div>
                <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${hadirPercentage}%` }} />
                </div>
              </div>
            </div>

            <div className="text-[10px] text-slate-505 bg-violet-50/20 p-2 border border-violet-100/30 rounded-xl leading-relaxed">
              *Hanya warga terabsen "Hadir" hari ini yang dapat ditarik pada form isian pemeriksaan medis dinkes.
            </div>
          </div>
        </div>

      </div>

      {/* Recent Histories table */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm font-sans">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider font-mono">Riwayat Pencatatan Klinik Terbaru</h3>
            <p className="text-[11px] text-slate-450">Tabel log audit rekam medis dinkes</p>
          </div>
          <button 
            onClick={() => onNavigate('tabel-grafik')}
            className="text-xs text-violet-600 hover:underline cursor-pointer font-bold font-mono uppercase"
          >
            Lihat semua
          </button>
        </div>

        {recentHistories.length === 0 ? (
          <p className="text-center py-6 text-slate-350 text-xs font-medium">Belum ada rekam medis diinput hari ini.</p>
        ) : (
          <div className="divide-y divide-slate-100 text-xs font-medium">
            {recentHistories.map((item) => (
              <div key={item.id} className="py-2.5 flex items-center justify-between hover:bg-slate-50/40 rounded px-1 transition-colors">
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-black ${
                    item.peran === 'BALITA' ? 'bg-violet-100 text-violet-800' :
                    item.peran === 'IBUHAMIL' ? 'bg-pink-100 text-pink-800' :
                    item.peran === 'LANSIA' ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {item.peran}
                  </span>
                  <div>
                    <p className="font-extrabold text-slate-900">{item.nama}</p>
                    <p className="text-[10px] text-slate-400 font-normal">Petugas: {item.petugas || 'Kader'} • {item.detail}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[9px] text-slate-400">{item.tanggal}</p>
                  <p className="text-[8px] bg-violet-500/10 text-violet-700 font-black rounded px-1 mt-0.5 inline-block border border-violet-500/15 font-mono">TERSEPAN</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
