import React, { useState } from 'react';
import { 
  Search, Filter, BookOpen, UserCheck, Trash2, Edit2, FileDown, Check, X, MapPin, Heart, Users, Calendar, Eye
} from 'lucide-react';
import { MasterAnggota, Attendance, PemeriksaanBalita, PemeriksaanKategoriLain } from '../types';

interface DataTabelProps {
  masterAnggota: MasterAnggota[];
  attendances: Attendance[];
  pemeriksaanBalita: PemeriksaanBalita[];
  pemeriksaanLain: PemeriksaanKategoriLain[];
  onDeleteMasterAnggota: (kodeUnik: string) => void;
  onDeleteAttendance: (id: string) => void;
  onDeletePemeriksaanBalita: (id: string) => void;
  onDeletePemeriksaanLain: (id: string) => void;
  onUpdateMasterAnggota: (updated: MasterAnggota) => void;
  onUpdatePemeriksaanBalita: (updated: PemeriksaanBalita) => void;
  onUpdatePemeriksaanLain: (updated: PemeriksaanKategoriLain) => void;
}

export default function DataTabel({
  masterAnggota,
  attendances,
  pemeriksaanBalita,
  pemeriksaanLain,
  onDeleteMasterAnggota,
  onDeleteAttendance,
  onDeletePemeriksaanBalita,
  onDeletePemeriksaanLain,
  onUpdateMasterAnggota,
  onUpdatePemeriksaanBalita,
  onUpdatePemeriksaanLain
}: DataTabelProps) {

  // Active sheets mapping: 
  // 's1-master' = Sheet 1 Master Anggota
  // 's2-absen' = Sheet 2 Hasil Absen
  // 's3-pemeriksaan' = Sheet 3 Register Pemeriksaan
  const [activeSheetTab, setActiveSheetTab] = useState<'s1-master' | 's2-absen' | 's3-pemeriksaan'>('s3-pemeriksaan');
  const [pemeriksaanSubTab, setPemeriksaanSubTab] = useState<'balita' | 'lain'>('balita');

  // Search & Filter state
  const [query, setQuery] = useState('');
  const [filterPosyandu, setFilterPosyandu] = useState('ALL');

  // Inline editing states
  const [editingId, setEditingId] = useState<string | null>(null);

  // Draft editing states (any typed)
  const [draftMaster, setDraftMaster] = useState<MasterAnggota | null>(null);
  const [draftBalita, setDraftBalita] = useState<PemeriksaanBalita | null>(null);
  const [draftLain, setDraftLain] = useState<PemeriksaanKategoriLain | null>(null);

  // Filters helpers
  const matchesSearch = (name: string, extra?: string) => {
    const q = query.toLowerCase();
    return name.toLowerCase().includes(q) || (extra && extra.toLowerCase().includes(q));
  };

  const matchesPosyandu = (posyandu: string) => {
    return filterPosyandu === 'ALL' || posyandu === filterPosyandu;
  };

  // Filtered lists
  const filteredMaster = masterAnggota.filter(
    m => matchesSearch(m.nama, m.kodeUnik) && matchesPosyandu(m.posyandu)
  );

  const filteredAttendances = attendances.filter(
    a => matchesSearch(a.nama, a.kodeUnik) && matchesPosyandu(a.posyandu)
  );

  const filteredBalita = pemeriksaanBalita.filter(
    b => matchesSearch(b.nama) && matchesPosyandu(b.posyandu)
  );

  const filteredLain = pemeriksaanLain.filter(
    l => matchesSearch(l.nama) && matchesPosyandu(l.posyandu)
  );

  // Inline edit actions
  const startEditMaster = (m: MasterAnggota) => {
    setEditingId(m.kodeUnik);
    setDraftMaster({ ...m });
  };

  const saveEditMaster = () => {
    if (draftMaster) {
      onUpdateMasterAnggota(draftMaster);
      setEditingId(null);
      setDraftMaster(null);
    }
  };

  const startEditBalita = (b: PemeriksaanBalita) => {
    setEditingId(b.id);
    setDraftBalita({ ...b, tanggalEdit: new Date().toISOString().split('T')[0] });
  };

  const saveEditBalita = () => {
    if (draftBalita) {
      onUpdatePemeriksaanBalita(draftBalita);
      setEditingId(null);
      setDraftBalita(null);
    }
  };

  const startEditLain = (l: PemeriksaanKategoriLain) => {
    setEditingId(l.id);
    setDraftLain({ ...l, tanggalEdit: new Date().toISOString().split('T')[0] });
  };

  const saveEditLain = () => {
    if (draftLain) {
      onUpdatePemeriksaanLain(draftLain);
      setEditingId(null);
      setDraftLain(null);
    }
  };

  // CSV Exporter per sheet
  const handleExportCSV = (sheet: 's1' | 's2' | 's3-balita' | 's3-lain') => {
    let headers: string[] = [];
    let rows: string[][] = [];
    let titleSlug = '';

    if (sheet === 's1') {
      titleSlug = 'sheet1_master_anggota';
      headers = ['KODEUNIK', 'KATEGORI', 'NAMA', 'NIK', 'JENIS KELAMIN', 'TGLLAHIR', 'NAMAORTU', 'POSYANDU', 'ALAMAT'];
      rows = filteredMaster.map(m => [
        m.kodeUnik, m.kategori, m.nama, m.nik, m.jenisKelamin, m.tglLahir, m.namaOrtu, m.posyandu, m.alamat
      ]);
    } else if (sheet === 's2') {
      titleSlug = 'sheet2_hasil_absen';
      headers = ['TANGGAL', 'NAMA', 'KODEUNIK', 'KATEGORI', 'POSYANDU', 'STATUS'];
      rows = filteredAttendances.map(a => [
        a.tanggal, a.nama, a.kodeUnik, a.kategori, a.posyandu, a.status
      ]);
    } else if (sheet === 's3-balita') {
      titleSlug = 'sheet3_pemeriksaan_balita';
      headers = [
        'TANGGAL INPUT', 'TANGGAL EDIT', 'NAMA', 'NAMA ORTU', 'POSYANDU', 'BERAT BADAN', 'TINGGI BADAN', 
        'LILA', 'LINGKAR KEPALA', 'BB/U', 'PB/TB/U', 'BB menurut PB/TB', 'STATUS N/T/2T/O', 'CATATAN', 'PENGINPUT', 'PENGEDIT'
      ];
      rows = filteredBalita.map(b => [
        b.tanggalInput, b.tanggalEdit || '', b.nama, b.namaOrtu, b.posyandu, String(b.beratBadan), String(b.tinggiBadan),
        String(b.lila), String(b.lingkarKepala), b.bbU, b.pbTbU, b.bbPbTb, b.statusNTO, b.catatan, b.namaPenginput, b.namaPengedit || ''
      ]);
    } else if (sheet === 's3-lain') {
      titleSlug = 'sheet3_pemeriksaan_kategori_lain';
      headers = [
        'TANGGAL INPUT', 'TANGGAL EDIT', 'NAMA', 'POSYANDU', 'BERAT BADAN', 'TINGGI BADAN', 'LINGKAR PERUT',
        'LILA', 'TEKANAN DARAH', 'GULA DARAH', 'ASAM URAT', 'KOLESTEROL', 'CATATAN', 'PENGINPUT', 'PENGEDIT'
      ];
      rows = filteredLain.map(l => [
        l.tanggalInput, l.tanggalEdit || '', l.nama, l.posyandu, String(l.bb), String(l.tb), String(l.lingkarPerut),
        String(l.lila), l.tekananDarah, l.gulaDarah, l.asamUrat, l.kolesterol, l.catatan, l.namaPenginput, l.namaPengedit || ''
      ]);
    }

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${titleSlug}_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* 3 Sheets Subtab Switchbar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-sm font-black text-slate-800 flex items-center gap-1.5 uppercase font-mono tracking-wider">
              <Eye size={16} className="text-violet-600" />
              Sistem Viewer Data 3-Sheets Database
            </h2>
            <p className="text-[11px] text-slate-400">Arsip data master, kehadiran, dan diagnosis kesehatan Posyandu</p>
          </div>

          <div className="flex gap-1.5 p-1 bg-slate-50 border border-slate-150 rounded-xl w-full md:w-auto">
            <button
              onClick={() => { setActiveSheetTab('s1-master'); setEditingId(null); }}
              className={`flex-1 md:flex-none px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeSheetTab === 's1-master' ? 'bg-slate-900 text-white shadow' : 'text-slate-550 hover:bg-white hover:text-slate-800'
              }`}
            >
              <Users size={14} /> Sheet 1: Master
            </button>
            <button
              onClick={() => { setActiveSheetTab('s2-absen'); setEditingId(null); }}
              className={`flex-1 md:flex-none px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeSheetTab === 's2-absen' ? 'bg-slate-900 text-white shadow' : 'text-slate-550 hover:bg-white hover:text-slate-800'
              }`}
            >
              <Calendar size={14} /> Sheet 2: Absen
            </button>
            <button
              onClick={() => { setActiveSheetTab('s3-pemeriksaan'); setEditingId(null); }}
              className={`flex-1 md:flex-none px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeSheetTab === 's3-pemeriksaan' ? 'bg-slate-900 text-white shadow' : 'text-slate-550 hover:bg-white hover:text-slate-800'
              }`}
            >
              <BookOpen size={14} /> Sheet 3: Pemeriksaan
            </button>
          </div>
        </div>

        {/* Global Toolbar Filters */}
        <div className="p-4 bg-slate-50 rounded-xl grid grid-cols-1 md:grid-cols-3 gap-3.5">
          <div className="relative">
            <input
              type="text"
              placeholder="Cari nama atau kode warga..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 focus:outline-none focus:border-slate-800 rounded-lg text-xs text-slate-800"
            />
            <Search className="absolute left-2.5 top-2 text-slate-400" size={13} />
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold bg-white px-2.5 py-1 rounded-lg border border-slate-200">
            <Filter size={11} className="text-slate-400" />
            <select
              value={filterPosyandu}
              onChange={(e) => setFilterPosyandu(e.target.value)}
              className="bg-transparent border-none outline-none text-slate-800 cursor-pointer text-xs w-full font-bold"
            >
              <option value="ALL">Semua Posyandu</option>
              <option value="MINERAL 1">MINERAL 1</option>
              <option value="MINERAL 2">MINERAL 2</option>
              <option value="MAWAR">MAWAR</option>
              <option value="SEJAHTERA">SEJAHTERA</option>
              <option value="PROTEIN">PROTEIN</option>
              <option value="VITAMIN">VITAMIN</option>
            </select>
          </div>

          {/* Quick Export Active view as CSV */}
          <div className="flex justify-end">
            <button
              onClick={() => {
                if (activeSheetTab === 's1-master') handleExportCSV('s1');
                else if (activeSheetTab === 's2-absen') handleExportCSV('s2');
                else if (activeSheetTab === 's3-pemeriksaan') {
                  handleExportCSV(pemeriksaanSubTab === 'balita' ? 's3-balita' : 's3-lain');
                }
              }}
              className="w-full py-1.5 px-4 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-xs font-bold cursor-pointer flex items-center justify-center gap-1.5 transition"
            >
              <FileDown size={13} /> Ekstrak CSV Excel
            </button>
          </div>
        </div>

      </div>

      {/* CORE TABLE RENDERS BASED ON ACTIVE SUB TAB */}
      <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
        
        {/* VIEW 1: SHEET 1 MASTER ANGGOTA */}
        {activeSheetTab === 's1-master' && (
          <div className="overflow-x-auto text-[11px] text-slate-800">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100 text-slate-400 font-bold uppercase py-3 px-4">
                  <th className="py-2.5 px-4">KODEUNIK</th>
                  <th className="py-2.5 px-4">KATEGORI</th>
                  <th className="py-2.5 px-4">NAMA</th>
                  <th className="py-2.5 px-4">NIK</th>
                  <th className="py-2.5 px-4">L/P</th>
                  <th className="py-2.5 px-4">TGLLAHIR</th>
                  <th className="py-2.5 px-4">NAMAORTU</th>
                  <th className="py-2.5 px-4">POSYANDU</th>
                  <th className="py-2.5 px-4">ALAMAT</th>
                  <th className="py-2.5 px-4 text-right">AKSI</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredMaster.map(m => {
                  const isEd = editingId === m.kodeUnik;
                  return (
                    <tr key={m.kodeUnik} className="hover:bg-slate-50/20">
                      <td className="py-2.5 px-4 font-bold font-mono text-indigo-700">{m.kodeUnik}</td>
                      <td className="py-2.5 px-4 whitespace-nowrap">
                        {isEd ? (
                          <select
                            value={draftMaster?.kategori || 'BALITA'}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, kategori: e.target.value as any } : null)}
                            className="border p-0.5 rounded"
                          >
                            <option value="BALITA">BALITA</option>
                            <option value="KADER">KADER</option>
                            <option value="REMAJA">REMAJA</option>
                            <option value="IBUHAMIL">IBUHAMIL</option>
                            <option value="USIAPRODUKTIF">USIAPRODUKTIF</option>
                            <option value="LANSIA">LANSIA</option>
                          </select>
                        ) : (
                          <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-bold">{m.kategori}</span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-slate-900">
                        {isEd ? (
                          <input
                            type="text"
                            value={draftMaster?.nama || ''}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, nama: e.target.value } : null)}
                            className="border p-0.5 rounded w-32 font-bold"
                          />
                        ) : m.nama}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-slate-650">
                        {isEd ? (
                          <input
                            type="text"
                            value={draftMaster?.nik || ''}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, nik: e.target.value.replace(/\D/g, '') } : null)}
                            className="border p-0.5 rounded w-28 font-mono"
                            maxLength={17}
                          />
                        ) : m.nik}
                      </td>
                      <td className="py-2.5 px-4">
                        {isEd ? (
                          <select
                            value={draftMaster?.jenisKelamin || 'L'}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, jenisKelamin: e.target.value as any } : null)}
                            className="border p-0.5 rounded"
                          >
                            <option value="L">L</option>
                            <option value="P">P</option>
                          </select>
                        ) : m.jenisKelamin}
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 whitespace-nowrap font-mono text-[10px]">
                        {isEd ? (
                          <input
                            type="date"
                            value={draftMaster?.tglLahir || ''}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, tglLahir: e.target.value } : null)}
                            className="border p-0.5 rounded font-mono"
                          />
                        ) : m.tglLahir}
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 whitespace-nowrap">
                        {isEd ? (
                          <input
                            type="text"
                            value={draftMaster?.namaOrtu || ''}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, namaOrtu: e.target.value } : null)}
                            className="border p-0.5 rounded w-24"
                            placeholder="Khusus balita"
                          />
                        ) : (m.namaOrtu || '-')}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-purple-750">
                        {isEd ? (
                          <select
                            value={draftMaster?.posyandu || 'MINERAL 1'}
                            onChange={(e) => setDraftMaster(p => p ? { ...p, posyandu: e.target.value as any } : null)}
                            className="border p-0.5 rounded"
                          >
                            <option value="MINERAL 1">MINERAL 1</option>
                            <option value="MINERAL 2">MINERAL 2</option>
                            <option value="MAWAR">MAWAR</option>
                            <option value="SEJAHTERA">SEJAHTERA</option>
                            <option value="PROTEIN">PROTEIN</option>
                            <option value="VITAMIN">VITAMIN</option>
                          </select>
                        ) : m.posyandu}
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 max-w-xs">{isEd ? (
                        <textarea
                          rows={1}
                          value={draftMaster?.alamat || ''}
                          onChange={(e) => setDraftMaster(p => p ? { ...p, alamat: e.target.value } : null)}
                          className="border p-0.5 rounded w-32 text-[10px]"
                        />
                      ) : m.alamat}</td>
                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        {isEd ? (
                          <div className="flex gap-1.5 justify-end">
                            <button onClick={saveEditMaster} className="text-violet-600 font-extrabold cursor-pointer">Simpan</button>
                            <button onClick={() => setEditingId(null)} className="text-slate-400 cursor-pointer">Batal</button>
                          </div>
                        ) : (
                          <div className="flex gap-2 justify-end">
                            <button onClick={() => startEditMaster(m)} className="text-indigo-600 hover:underline cursor-pointer">Edit</button>
                            <button onClick={() => onDeleteMasterAnggota(m.kodeUnik)} className="text-red-500 hover:underline cursor-pointer">Delete</button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* VIEW 2: SHEET 2 DATA HASIL ABSEN */}
        {activeSheetTab === 's2-absen' && (
          <div className="overflow-x-auto text-[11px] text-slate-800">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100 text-slate-400 font-bold uppercase py-3 px-4">
                  <th className="py-2.5 px-4">TANGGAL</th>
                  <th className="py-2.5 px-4">NAMA</th>
                  <th className="py-2.5 px-4">KODEUNIK</th>
                  <th className="py-2.5 px-4">KATEGORI</th>
                  <th className="py-2.5 px-4">POSYANDU</th>
                  <th className="py-2.5 px-4">STATUS</th>
                  <th className="py-2.5 px-4 text-right">AKSI</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-semibold font-mono">
                {filteredAttendances.map(a => (
                  <tr key={a.id} className="hover:bg-slate-50/10 text-slate-700">
                    <td className="py-2.5 px-4 font-mono font-bold text-slate-500">{a.tanggal}</td>
                    <td className="py-2.5 px-4 font-sans font-black text-slate-900">{a.nama}</td>
                    <td className="py-2.5 px-4 text-indigo-750 font-bold">{a.kodeUnik}</td>
                    <td className="py-2.5 px-4 font-sans text-slate-500 font-bold text-[10px]">
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded">{a.kategori}</span>
                    </td>
                    <td className="py-2.5 px-4 text-purple-750 font-bold">{a.posyandu}</td>
                    <td className="py-2.5 px-4 font-sans font-bold">
                      <span className="text-violet-700 bg-violet-50 px-2 py-0.5 rounded border border-violet-100">
                        {a.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right font-sans font-bold">
                      <button
                        onClick={() => onDeleteAttendance(a.id)}
                        className="text-red-500 hover:text-red-700 cursor-pointer"
                      >
                        Hapus Record
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* VIEW 3: SHEET 3 DATA HASIL INPUT PEMERIKSAAN (SPLIT BALITA & OTHER COHORTS TABLES) */}
        {activeSheetTab === 's3-pemeriksaan' && (
          <div className="space-y-4">
            
            {/* Split Switcher for Sheet 3 Sub Tables */}
            <div className="p-3 border-b border-slate-100 bg-slate-50/40 flex items-center gap-1.5">
              <button
                onClick={() => { setPemeriksaanSubTab('balita'); setEditingId(null); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  pemeriksaanSubTab === 'balita' ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600'
                }`}
              >
                Tabel Khusus BALITA (Bayi & Anak)
              </button>
              <button
                onClick={() => { setPemeriksaanSubTab('lain'); setEditingId(null); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  pemeriksaanSubTab === 'lain' ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600'
                }`}
              >
                Tabel KADER, IBU HAMIL, LANSIA, REMAJA & USIA PROD
              </button>
            </div>

            {/* TABULAR LAYOUT A: BALITA DETAILED EXAMINATION REPORT VIEW */}
            {pemeriksaanSubTab === 'balita' ? (
              <div className="overflow-x-auto text-[10px] md:text-[11px] text-slate-800">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50/50 border-b border-slate-100 text-slate-400 font-bold uppercase">
                      <th className="py-2.5 px-3">INPUT</th>
                      <th className="py-2.5 px-3">EDIT</th>
                      <th className="py-2.5 px-3">NAMA (BALITA)</th>
                      <th className="py-2.5 px-3">NAMA ORTU</th>
                      <th className="py-2.5 px-3">POSYANDU</th>
                      <th className="py-2.5 px-3">BB (KG)</th>
                      <th className="py-2.5 px-3">TB (CM)</th>
                      <th className="py-2.5 px-3">LILA (CM)</th>
                      <th className="py-2.5 px-3">L. KEPALA</th>
                      <th className="py-2.5 px-3">BB/U</th>
                      <th className="py-2.5 px-3">PB/TB/U</th>
                      <th className="py-2.5 px-3">BB menurut PB/TB</th>
                      <th className="py-2.5 px-3">N/T/2T/O</th>
                      <th className="py-2.5 px-3">CATATAN</th>
                      <th className="py-2.5 px-3">PENGINPUT</th>
                      <th className="py-2.5 px-3">PENGEDIT</th>
                      <th className="py-2.5 px-3 text-right">AKSI</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {filteredBalita.map(b => {
                      const isEd = editingId === b.id;
                      return (
                        <tr key={b.id} className="hover:bg-slate-50/20">
                          <td className="py-2.5 px-3 whitespace-nowrap font-mono">{b.tanggalInput}</td>
                          <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[9px] text-slate-400">{b.tanggalEdit || '-'}</td>
                          <td className="py-2.5 px-3 font-bold text-slate-900">{b.nama}</td>
                          <td className="py-2.5 px-3 text-slate-505">{b.namaOrtu}</td>
                          <td className="py-2.5 px-3 font-bold text-purple-750">{b.posyandu}</td>
                          <td className="py-2.5 px-3 font-mono font-bold">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.01"
                                value={draftBalita?.beratBadan || ''}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, beratBadan: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : b.beratBadan}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftBalita?.tinggiBadan || ''}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, tinggiBadan: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : b.tinggiBadan}
                          </td>
                          <td className="py-2.5 px-3 font-mono">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftBalita?.lila || ''}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, lila: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : b.lila}
                          </td>
                          <td className="py-2.5 px-3 font-mono">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftBalita?.lingkarKepala || ''}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, lingkarKepala: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : b.lingkarKepala}
                          </td>
                          <td className="py-2.5 px-3 font-semibold whitespace-nowrap text-indigo-700 font-mono text-[9px]">
                            {isEd ? (
                              <select
                                value={draftBalita?.bbU || 'NORMAL'}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, bbU: e.target.value as any } : null)}
                                className="border p-0.5 rounded text-[9px]"
                              >
                                <option value="SANGATKURANG">SANGATKURANG</option>
                                <option value="KURANG">KURANG</option>
                                <option value="NORMAL">NORMAL</option>
                                <option value="RESIKO BB LEBIH">RESIKO BB LEBIH</option>
                              </select>
                            ) : b.bbU}
                          </td>
                          <td className="py-2.5 px-3 font-semibold whitespace-nowrap text-indigo-700 font-mono text-[9px]">
                            {isEd ? (
                              <select
                                value={draftBalita?.pbTbU || 'NORMAL'}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, pbTbU: e.target.value as any } : null)}
                                className="border p-0.5 rounded text-[9px]"
                              >
                                <option value="SANGATPENDEK">SANGATPENDEK</option>
                                <option value="PENDEK">PENDEK</option>
                                <option value="NORMAL">NORMAL</option>
                                <option value="TINGGI">TINGGI</option>
                              </select>
                            ) : b.pbTbU}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap font-semibold">
                            {isEd ? (
                              <select
                                value={draftBalita?.bbPbTb || 'GIZI BAIK'}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, bbPbTb: e.target.value as any } : null)}
                                className="border p-0.5 rounded text-[9px]"
                              >
                                <option value="GIZI BURUK">GIZI BURUK</option>
                                <option value="GIZI KURANG">GIZI KURANG</option>
                                <option value="GIZI BAIK">GIZI BAIK</option>
                                <option value="BERISIKO GIZI LEBIH">BERISIKO GIZI LEBIH</option>
                                <option value="GIZI LEBIH">GIZI LEBIH</option>
                                <option value="OBESITAS">OBESITAS</option>
                              </select>
                            ) : b.bbPbTb}
                          </td>
                          <td className="py-2.5 px-3 font-bold font-sans">
                            {isEd ? (
                              <select
                                value={draftBalita?.statusNTO || 'N'}
                                onChange={(e) => setDraftBalita(p => p ? { ...p, statusNTO: e.target.value as any } : null)}
                                className="border p-0.5 rounded text-[10px]"
                              >
                                <option value="N">N</option>
                                <option value="T">T</option>
                                <option value="2T">2T</option>
                                <option value="O">O</option>
                              </select>
                            ) : b.statusNTO}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500 italic max-w-[120px] truncate">{isEd ? (
                            <input
                              type="text"
                              value={draftBalita?.catatan || ''}
                              onChange={(e) => setDraftBalita(p => p ? { ...p, catatan: e.target.value } : null)}
                              className="border p-0.5 rounded w-16 text-[10px]"
                            />
                          ) : b.catatan}</td>
                          <td className="py-2.5 px-3 text-slate-500 font-semibold">{b.namaPenginput}</td>
                          <td className="py-2.5 px-3 text-slate-400 font-mono text-[9px]">{b.namaPengedit || '-'}</td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap font-sans font-bold">
                            {isEd ? (
                              <div className="flex gap-1">
                                <button onClick={saveEditBalita} className="text-violet-750 cursor-pointer">Simpan</button>
                                <button onClick={() => setEditingId(null)} className="text-slate-400 cursor-pointer">Batal</button>
                              </div>
                            ) : (
                              <div className="flex gap-1.5 justify-end">
                                <button onClick={() => startEditBalita(b)} className="text-indigo-600 hover:underline cursor-pointer">Edit</button>
                                <button onClick={() => onDeletePemeriksaanBalita(b.id)} className="text-red-500 hover:underline cursor-pointer">Delete</button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              // TABULAR LAYOUT B: NON-BALITA EXAMINATION RECORDS VIEW
              <div className="overflow-x-auto text-[10px] md:text-[11px] text-slate-850">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50/50 border-b border-slate-100 text-slate-400 font-bold uppercase">
                      <th className="py-2.5 px-4">INPUT</th>
                      <th className="py-2.5 px-4">EDIT</th>
                      <th className="py-2.5 px-4">NAMA WARGA</th>
                      <th className="py-2.5 px-4 font-normal">KATEGORI</th>
                      <th className="py-2.5 px-4">POSYANDU</th>
                      <th className="py-2.5 px-4">BB (KG)</th>
                      <th className="py-2.5 px-4">TB (CM)</th>
                      <th className="py-2.5 px-4">L. PERUT</th>
                      <th className="py-2.5 px-4">LILA</th>
                      <th className="py-2.5 px-4 font-semibold text-red-650">TEKANAN DARAH</th>
                      <th className="py-2.5 px-4 font-semibold text-rose-650">GULA DARAH</th>
                      <th className="py-2.5 px-4 font-semibold text-indigo-750">ASAM URAT</th>
                      <th className="py-2.5 px-4 font-semibold text-amber-750">KOLESTEROL</th>
                      <th className="py-2.5 px-4">CATATAN</th>
                      <th className="py-2.5 px-4">PENGINPUT</th>
                      <th className="py-2.5 px-4 text-slate-400">PENGEDIT</th>
                      <th className="py-2.5 px-4 text-right">AKSI</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium font-sans">
                    {filteredLain.map(l => {
                      const isEd = editingId === l.id;
                      return (
                        <tr key={l.id} className="hover:bg-slate-50/20">
                          <td className="py-2.5 px-4 whitespace-nowrap font-mono">{l.tanggalInput}</td>
                          <td className="py-2.5 px-4 whitespace-nowrap font-mono text-[9px] text-slate-400">{l.tanggalEdit || '-'}</td>
                          <td className="py-2.5 px-4 font-bold text-slate-900">{l.nama}</td>
                          <td className="py-2.5 px-4">
                            <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-bold font-mono text-[9px]">{l.kategori}</span>
                          </td>
                          <td className="py-2.5 px-4 font-bold text-purple-750">{l.posyandu}</td>
                          <td className="py-2.5 px-4 font-mono font-bold">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftLain?.bb || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, bb: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : l.bb}
                          </td>
                          <td className="py-2.5 px-4 font-mono font-bold">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftLain?.tb || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, tb: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : l.tb}
                          </td>
                          <td className="py-2.5 px-4 font-mono">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftLain?.lingkarPerut || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, lingkarPerut: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : l.lingkarPerut}
                          </td>
                          <td className="py-2.5 px-4 font-mono">
                            {isEd ? (
                              <input
                                type="number"
                                step="0.1"
                                value={draftLain?.lila || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, lila: parseFloat(e.target.value) } : null)}
                                className="border p-0.5 rounded w-12 text-[10px]"
                              />
                            ) : l.lila}
                          </td>
                          {/* TEKANAN DARAH */}
                          <td className="py-2.5 px-4 font-mono font-bold text-red-750">
                            {isEd ? (
                              <input
                                type="text"
                                value={draftLain?.tekananDarah || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, tekananDarah: e.target.value } : null)}
                                className="border p-0.5 rounded w-16 text-[10px]"
                              />
                            ) : (
                              <span className={l.tekananDarah === 'Habis' || l.tekananDarah === 'Alat Kosong' ? 'text-slate-400 font-bold font-sans tracking-wide border border-dashed rounded px-1 text-[9px]' : ''}>
                                {l.tekananDarah}
                              </span>
                            )}
                          </td>
                          {/* GULA DARAH */}
                          <td className="py-2.5 px-4 font-mono font-bold text-rose-750">
                            {isEd ? (
                              <input
                                type="text"
                                value={draftLain?.gulaDarah || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, gulaDarah: e.target.value } : null)}
                                className="border p-0.5 rounded w-14 text-[10px]"
                              />
                            ) : (
                              <span className={l.gulaDarah === 'Habis' || l.gulaDarah === 'Alat Kosong' ? 'text-slate-400 font-bold font-sans tracking-wide border border-dashed rounded px-1 text-[9px]' : ''}>
                                {l.gulaDarah}
                              </span>
                            )}
                          </td>
                          {/* ASAM URAT */}
                          <td className="py-2.5 px-4 font-mono font-bold text-indigo-750">
                            {isEd ? (
                              <input
                                type="text"
                                value={draftLain?.asamUrat || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, asamUrat: e.target.value } : null)}
                                className="border p-0.5 rounded w-14 text-[10px]"
                              />
                            ) : (
                              <span className={l.asamUrat === 'Habis' || l.asamUrat === 'Alat Kosong' ? 'text-slate-400 font-bold font-sans tracking-wide border border-dashed rounded px-1 text-[9px]' : ''}>
                                {l.asamUrat}
                              </span>
                            )}
                          </td>
                          {/* KOLESTEROL */}
                          <td className="py-2.5 px-4 font-mono font-bold text-amber-750">
                            {isEd ? (
                              <input
                                type="text"
                                value={draftLain?.kolesterol || ''}
                                onChange={(e) => setDraftLain(p => p ? { ...p, kolesterol: e.target.value } : null)}
                                className="border p-0.5 rounded w-14 text-[10px]"
                              />
                            ) : (
                              <span className={l.kolesterol === 'Habis' || l.kolesterol === 'Alat Kosong' ? 'text-slate-400 font-bold font-sans tracking-wide border border-dashed rounded px-1 text-[9px]' : ''}>
                                {l.kolesterol}
                              </span>
                            )}
                          </td>
                          {/* CATATAN */}
                          <td className="py-2.5 px-4 text-slate-500 italic max-w-[120px] truncate">{isEd ? (
                            <input
                              type="text"
                              value={draftLain?.catatan || ''}
                              onChange={(e) => setDraftLain(p => p ? { ...p, catatan: e.target.value } : null)}
                              className="border p-0.5 rounded w-20 text-[10px]"
                            />
                          ) : l.catatan}</td>
                          <td className="py-2.5 px-4 text-slate-550 font-semibold">{l.namaPenginput}</td>
                          <td className="py-2.5 px-4 text-slate-400 font-mono text-[9px]">{l.namaPengedit || '-'}</td>
                          <td className="py-2.5 px-4 text-right whitespace-nowrap font-sans font-bold">
                            {isEd ? (
                              <div className="flex gap-1">
                                <button onClick={saveEditLain} className="text-violet-750 cursor-pointer">Simpan</button>
                                <button onClick={() => setEditingId(null)} className="text-slate-400 cursor-pointer">Batal</button>
                              </div>
                            ) : (
                              <div className="flex gap-1.5 justify-end">
                                <button onClick={() => startEditLain(l)} className="text-indigo-600 hover:underline cursor-pointer">Edit</button>
                                <button onClick={() => onDeletePemeriksaanLain(l.id)} className="text-red-500 hover:underline cursor-pointer">Delete</button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

          </div>
        )}

      </div>

    </div>
  );
}
