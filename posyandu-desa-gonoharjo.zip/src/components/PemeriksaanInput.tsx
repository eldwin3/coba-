import React, { useState, useEffect } from 'react';
import { 
  FileHeart, ClipboardCheck, ArrowRight, UserCheck, RefreshCw, AlertCircle, Sparkles, HeartHandshake, Info
} from 'lucide-react';
import { MasterAnggota, Attendance, PemeriksaanBalita, PemeriksaanKategoriLain } from '../types';

interface PemeriksaanInputProps {
  masterAnggota: MasterAnggota[];
  attendances: Attendance[];
  onAddAttendance?: (attendance: Attendance) => void;
  onAddPemeriksaanBalita: (exam: PemeriksaanBalita) => void;
  onAddPemeriksaanLain: (exam: PemeriksaanKategoriLain) => void;
  selectedAttendeeCode?: string;
  clearSelectedAttendeeCode?: () => void;
  currentUser: string;
  onNavigateToTab: (tab: string) => void;
}

export default function PemeriksaanInput({
  masterAnggota,
  attendances,
  onAddAttendance,
  onAddPemeriksaanBalita,
  onAddPemeriksaanLain,
  selectedAttendeeCode,
  clearSelectedAttendeeCode,
  currentUser,
  onNavigateToTab
}: PemeriksaanInputProps) {
  
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(todayStr);

  // Filter attendees for selected template date
  const dailyAttendees = attendances.filter(a => a.tanggal === selectedDate);

  // Dropdown selected active attendee code
  const [activeCode, setActiveCode] = useState('');

  // Quick text input for code lookup
  const [inputedCode, setInputedCode] = useState('');

  // Auto-fill metadata upon selecting code
  const [activeMember, setActiveMember] = useState<MasterAnggota | null>(null);

  // Common notification feedback state
  const [notification, setNotification] = useState('');

  // --- FORM STATES: BALITA ---
  const [balitaBb, setBalitaBb] = useState('');
  const [balitaTb, setBalitaTb] = useState('');
  const [balitaLila, setBalitaLila] = useState('');
  const [balitaLk, setBalitaLk] = useState('');
  const [balitaBbu, setBalitaBbu] = useState<'SANGATKURANG' | 'KURANG' | 'NORMAL' | 'RESIKO BB LEBIH'>('NORMAL');
  const [balitaPbtbu, setBalitaPbtbu] = useState<'SANGATPENDEK' | 'PENDEK' | 'NORMAL' | 'TINGGI'>('NORMAL');
  const [balitaBbpbtb, setBalitaBbpbtb] = useState<'GIZI BURUK' | 'GIZI KURANG' | 'GIZI BAIK' | 'BERISIKO GIZI LEBIH' | 'GIZI LEBIH' | 'OBESITAS'>('GIZI BAIK');
  const [balitaStatusNto, setBalitaStatusNto] = useState<'N' | 'T' | '2T' | 'O'>('N');
  const [balitaCatatan, setBalitaCatatan] = useState('');

  // --- FORM STATES: NON-BALITA ---
  const [lainBb, setLainBb] = useState('');
  const [lainTb, setLainTb] = useState('');
  const [lainLp, setLainLp] = useState('');
  const [lainLila, setLainLila] = useState('');
  
  // Custom states that can also be "HABIS" or "ALATKOSONG"
  const [lainTd, setLainTd] = useState('');
  const [lainGds, setLainGds] = useState('');
  const [lainAu, setLainAu] = useState('');
  const [lainKoles, setLainKoles] = useState('');
  const [lainCatatan, setLainCatatan] = useState('');

  // Inject selected code from quick shortcuts
  useEffect(() => {
    if (selectedAttendeeCode) {
      setActiveCode(selectedAttendeeCode);
      setInputedCode(selectedAttendeeCode);
      if (clearSelectedAttendeeCode) clearSelectedAttendeeCode();
    }
  }, [selectedAttendeeCode]);

  // Sync active member data when activeCode selection changes
  useEffect(() => {
    const member = masterAnggota.find(m => m.kodeUnik === activeCode);
    setActiveMember(member || null);
  }, [activeCode, masterAnggota]);

  // Handle typing key search lookup
  const handleCodeLookupChange = (val: string) => {
    setInputedCode(val);
    const clean = val.trim().toUpperCase();
    const foundAttendee = dailyAttendees.find(a => a.kodeUnik.toUpperCase() === clean);
    if (foundAttendee) {
      setActiveCode(foundAttendee.kodeUnik);
    } else {
      setActiveCode('');
    }
  };

  // Instant on-the-fly check-in registration
  const handleInstantCheckIn = (member: MasterAnggota) => {
    if (onAddAttendance) {
      const newAttendance: Attendance = {
        id: `ATT-${Date.now()}-${member.kodeUnik}`,
        tanggal: selectedDate,
        nama: member.nama,
        kodeUnik: member.kodeUnik,
        kategori: member.kategori,
        posyandu: member.posyandu,
        status: 'Hadir'
      };
      onAddAttendance(newAttendance);
      setActiveCode(member.kodeUnik);
      setNotification(`✓ Otomatis absen Hadir berhasil untuk ${member.nama}!`);
      setTimeout(() => setNotification(''), 4500);
    }
  };

  // Helper selectors for fast settings of special instrument values
  const setInstrumentSpecial = (tracker: 'td' | 'gds' | 'au' | 'koles', value: 'HABIS' | 'ALATKOSONG' | string) => {
    if (tracker === 'td') setLainTd(value);
    if (tracker === 'gds') setLainGds(value);
    if (tracker === 'au') setLainAu(value);
    if (tracker === 'koles') setLainKoles(value);
  };

  // Reset form inputs helper
  const resetForms = () => {
    // balita resets
    setBalitaBb('');
    setBalitaTb('');
    setBalitaLila('');
    setBalitaLk('');
    setBalitaBbu('NORMAL');
    setBalitaPbtbu('NORMAL');
    setBalitaBbpbtb('GIZI BAIK');
    setBalitaStatusNto('N');
    setBalitaCatatan('');

    // other resets
    setLainBb('');
    setLainTb('');
    setLainLp('');
    setLainLila('');
    setLainTd('');
    setLainGds('');
    setLainAu('');
    setLainKoles('');
    setLainCatatan('');

    setActiveCode('');
    setInputedCode('');
  };

  // --- HANDLER: SUBMIT EXAMINATION REPORT ---
  const handleSubmitExamination = (e: React.FormEvent) => {
    e.preventDefault();
    setNotification('');

    if (!activeMember) {
      alert('Harap pilih Warga yang ter-Absen terlebih dahulu!');
      return;
    }

    if (activeMember.kategori === 'BALITA') {
      // "SEMUA DATA HARUS TERISI KECUALI CATATAN"
      if (!balitaBb || !balitaTb || !balitaLila || !balitaLk || !balitaBbu || !balitaPbtbu || !balitaBbpbtb || !balitaStatusNto) {
        alert('Gagal disimpan! Semua parameter medis balita harus terisi kecuali Catatan.');
        return;
      }

      const balitaReport: PemeriksaanBalita = {
        id: `EXB-${Date.now()}`,
        tanggalInput: selectedDate,
        tanggalEdit: null,
        nama: activeMember.nama,
        namaOrtu: activeMember.namaOrtu || 'Tidak Ada',
        posyandu: activeMember.posyandu,
        beratBadan: parseFloat(balitaBb),
        tinggiBadan: parseFloat(balitaTb),
        lila: parseFloat(balitaLila),
        lingkarKepala: parseFloat(balitaLk),
        bbU: balitaBbu,
        pbTbU: balitaPbtbu,
        bbPbTb: balitaBbpbtb,
        statusNTO: balitaStatusNto,
        catatan: balitaCatatan.trim(),
        namaPenginput: currentUser,
        namaPengedit: null
      };

      onAddPemeriksaanBalita(balitaReport);
      setNotification(`Sukses menyimpan pemeriksaan Balita: ${activeMember.nama}!`);
      resetForms();

    } else {
      // Other categories: KADER, REMAJA, IBUHAMIL, USIAPRODUKTIF, LANSIA
      // "SEMUA DATA HARUS TERISI KECUALI CATATAN" - Tekanan darah, Gula Darah, Asam Urat, Kolesterol can be numbers or "HABIS" / "ALATKOSONG"
      if (!lainBb || !lainTb || !lainLp || !lainLila || !lainTd.trim() || !lainGds.trim() || !lainAu.trim() || !lainKoles.trim()) {
        alert('Gagal disimpan! Semua kolom harus diisi termasuk instrumen penunjang (atau set HABIS / ALATKOSONG) kecuali Catatan.');
        return;
      }

      const otherReport: PemeriksaanKategoriLain = {
        id: `EXL-${Date.now()}`,
        tanggalInput: selectedDate,
        tanggalEdit: null,
        nama: activeMember.nama,
        kategori: activeMember.kategori as any,
        posyandu: activeMember.posyandu,
        bb: parseFloat(lainBb),
        tb: parseFloat(lainTb),
        lingkarPerut: parseFloat(lainLp),
        lila: parseFloat(lainLila),
        tekananDarah: lainTd.trim(),
        gulaDarah: lainGds.trim(),
        asamUrat: lainAu.trim(),
        kolesterol: lainKoles.trim(),
        catatan: lainCatatan.trim(),
        namaPenginput: currentUser,
        namaPengedit: null
      };

      onAddPemeriksaanLain(otherReport);
      setNotification(`Sukses menyimpan pemeriksaan ${activeMember.kategori}: ${activeMember.nama}!`);
      resetForms();
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
      
      {/* Page Header */}
      <div className="flex items-center gap-3 border-b border-slate-50 pb-4">
        <div className="p-2.5 bg-indigo-50 text-indigo-650 rounded-xl">
          <FileHeart size={22} fill="currentColor" className="opacity-80" />
        </div>
        <div>
          <h2 className="text-base font-extrabold text-slate-800">Pencatatan Hasil Pemeriksaan Medis</h2>
          <p className="text-xs text-slate-400">Verifikasi kehadiran dan isi pengukuran klinis sasaran</p>
        </div>
      </div>

      {notification && (
        <div className="p-3 bg-violet-50 text-violet-800 rounded-xl border border-violet-100 font-bold text-xs flex items-center gap-1.5 animate-pulse">
          <span>✔</span> {notification}
        </div>
      )}

      {/* Date & Core Attendee Validation selectors */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-150 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Select Date */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Tanggal Kegiatan Layanan
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => {
                setSelectedDate(e.target.value);
                setActiveCode('');
                setInputedCode('');
              }}
              className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600 font-semibold"
            />
          </div>

          {/* Quick Input unique code */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex justify-between">
              <span>Masukkan Kode Unik</span>
              <span className="text-[10px] text-violet-600 font-black">CEPAT</span>
            </label>
            <div className="relative">
              <input
                id="pemeriksaan-quick-input-code"
                type="text"
                placeholder="Ketik/Scan e.g. BLA-MIN1"
                value={inputedCode}
                onChange={(e) => handleCodeLookupChange(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 focus:outline-none focus:border-indigo-600 rounded-xl text-xs font-mono font-bold uppercase placeholder:font-sans placeholder:font-normal"
              />
              {inputedCode && (
                <button
                  type="button"
                  onClick={() => {
                    setInputedCode('');
                    setActiveCode('');
                  }}
                  className="absolute right-2.5 top-1.5 text-slate-400 hover:text-slate-600 font-bold"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Fallback Dropdown List */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex justify-between">
              <span>Pilih Warga ({dailyAttendees.length} Hadir)</span>
              <span className="text-[10px] text-indigo-700 font-bold font-mono">DROPDOWN</span>
            </label>
            {dailyAttendees.length === 0 ? (
              <div className="py-2.5 px-3 bg-amber-50 rounded-xl border border-amber-205 text-amber-900 text-[10px]">
                Belum ada yang check-in Absen hari ini!
              </div>
            ) : (
              <select
                value={activeCode}
                onChange={(e) => {
                  const val = e.target.value;
                  setActiveCode(val);
                  setInputedCode(val);
                }}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-indigo-600"
              >
                <option value="">-- PILIHAN DROPDOWN --</option>
                {dailyAttendees.map(a => (
                  <option key={a.id} value={a.kodeUnik}>
                    {a.nama} ({a.kodeUnik} • {a.kategori})
                  </option>
                ))}
              </select>
            )}
          </div>

        </div>

        {/* Real-time lookup helper feedback */}
        {inputedCode.trim() && (
          <div className="p-3 bg-white border border-slate-100 rounded-xl text-xs animate-fade-in shadow-inner">
            {(() => {
              const clean = inputedCode.trim().toUpperCase();
              const matchedInMaster = masterAnggota.find(m => m.kodeUnik.toUpperCase() === clean);
              if (!matchedInMaster) {
                return (
                  <div className="flex items-center gap-1.5 text-red-650 font-bold">
                    <span>❌</span>
                    <span>Kode Unik "{clean}" tidak ditemukan di database Master Anggota!</span>
                  </div>
                );
              }

              const isAlreadyCheckedIn = dailyAttendees.some(a => a.kodeUnik.toUpperCase() === clean);
              if (isAlreadyCheckedIn) {
                return (
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                    <div className="flex items-center gap-2 text-violet-700 font-bold">
                      <span className="text-violet-500 text-sm">✓</span>
                      <span>Sasaran Ditemukan: <b className="text-slate-900 font-black">{matchedInMaster.nama}</b> ({matchedInMaster.kategori} • {matchedInMaster.posyandu}) - <span className="bg-violet-100 text-violet-800 px-1.5 py-0.5 rounded text-[10px] font-mono">SUDAH ABSEN</span></span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">Formulir siap diisi di bawah</span>
                  </div>
                );
              }

              return (
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 text-amber-700 font-bold">
                      <span>⚠</span>
                      <span>Ketemu Master: <b className="text-slate-900 font-black">{matchedInMaster.nama}</b> ({matchedInMaster.kategori})</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">
                      Butuh presensi! Sasaran terdaftar di Master, tetapi <b>Belum Check-In</b> hari ini ({selectedDate}).
                    </p>
                  </div>
                  {onAddAttendance ? (
                    <button
                      type="button"
                      onClick={() => handleInstantCheckIn(matchedInMaster)}
                      className="py-1.5 px-3 bg-violet-600 hover:bg-violet-700 text-white font-extrabold rounded-lg text-xs cursor-pointer flex items-center gap-1 transition shadow-sm whitespace-nowrap self-start sm:self-center"
                    >
                      <UserCheck size={13} /> Absenkan Hadir & Mulai Isian
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onNavigateToTab('input-absen')}
                      className="py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs cursor-pointer"
                    >
                      Buka Menu Absensi Manual
                    </button>
                  )}
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {/* Form Area depends on selected Attendee */}
      {!activeMember ? (
        <div className="py-12 text-center border border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center gap-2">
          <ClipboardCheck size={32} className="text-slate-300 animate-bounce" />
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">Pemeriksaan Tidak Aktif</h4>
          <p className="text-xs text-slate-400 max-w-sm leading-normal">
            Pilihlah salah satu nama warga dari dropdown di atas (yang telah melakukan absensi <b>Hadir</b> pada tanggal {selectedDate}) untuk memuat formulir masukan rekam medis kasta mereka.
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmitExamination} className="space-y-6">
          
          {/* Active Attendee Profile Summary Dashboard badge */}
          <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div className="space-y-0.5">
              <span className="bg-indigo-600 text-white font-mono text-[9px] font-bold px-1.5 py-0.5 rounded uppercase">
                {activeMember.kategori}
              </span>
              <h3 className="text-sm font-black text-slate-800">{activeMember.nama}</h3>
              <p className="text-xs text-slate-450 font-medium">
                NIK: <span className="font-mono text-slate-600">{activeMember.nik}</span> • Lahir: {activeMember.tglLahir} • Posyandu: {activeMember.posyandu}
              </p>
            </div>

            <div className="text-left sm:text-right text-[11px] font-mono shrink-0">
              <p className="text-slate-400">Kode Unik:</p>
              <p className="font-extrabold text-xs text-indigo-700">{activeMember.kodeUnik}</p>
              <p className="text-[10px] text-slate-400 mt-1 font-sans">Petugas Input: <b>{currentUser}</b></p>
            </div>
          </div>

          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-widest font-mono border-b border-slate-100 pb-2 flex items-center gap-1">
            <ActivityIcon size={14} className="text-indigo-650 animate-pulse" />
            Parameter Klinis Kategori: {activeMember.kategori}
          </h3>

          {/* FORM TYPE A: BALITA DETAILED LOGGING FIELDS */}
          {activeMember.kategori === 'BALITA' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-semibold text-slate-650">
              
              <div>
                <label className="block mb-1">Nama Orang Tua (Ibu/Ayah) <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={activeMember.namaOrtu || ''}
                  disabled
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block mb-1">Dusun / Wilayah POSYANDU <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={activeMember.posyandu}
                  disabled
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block mb-1">Berat Badan (BB - kg) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  placeholder="Misal: 9.2"
                  value={balitaBb}
                  onChange={(e) => setBalitaBb(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Tinggi / Panjang Badan (TB - cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="30"
                  placeholder="Misal: 78.5"
                  value={balitaTb}
                  onChange={(e) => setBalitaTb(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Lingkar Lengan Atas (LILA - cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  placeholder="Misal: 12.5"
                  value={balitaLila}
                  onChange={(e) => setBalitaLila(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Lingkar Kepala (cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  placeholder="Misal: 46"
                  value={balitaLk}
                  onChange={(e) => setBalitaLk(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              {/* Categorical Selections for Balita growth indicators */}
              <div>
                <label className="block mb-1 text-slate-700 font-bold">BB menurut Umur (BB/U) <span className="text-red-500">*</span></label>
                <select
                  value={balitaBbu}
                  onChange={(e) => setBalitaBbu(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-indigo-600 focus:outline-none rounded-lg text-slate-800 text-xs font-semibold"
                >
                  <option value="SANGATKURANG">SANGAT KURANG (SANGATKURANG)</option>
                  <option value="KURANG">KURANG</option>
                  <option value="NORMAL">NORMAL</option>
                  <option value="RESIKO BB LEBIH">RESIKO BB LEBIH</option>
                </select>
              </div>

              <div>
                <label className="block mb-1 text-slate-700 font-bold">PB/TB menurut Umur <span className="text-red-500">*</span></label>
                <select
                  value={balitaPbtbu}
                  onChange={(e) => setBalitaPbtbu(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-indigo-600 focus:outline-none rounded-lg text-slate-800 text-xs font-semibold"
                >
                  <option value="SANGATPENDEK">SANGAT PENDEK (SANGATPENDEK)</option>
                  <option value="PENDEK">PENDEK</option>
                  <option value="NORMAL">NORMAL</option>
                  <option value="TINGGI">TINGGI</option>
                </select>
              </div>

              <div>
                <label className="block mb-1 text-slate-700 font-bold">BB menurut PB/TB <span className="text-red-500">*</span></label>
                <select
                  value={balitaBbpbtb}
                  onChange={(e) => setBalitaBbpbtb(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-indigo-600 focus:outline-none rounded-lg text-slate-800 text-xs font-semibold"
                >
                  <option value="GIZI BURUK">GIZI BURUK (GIZIBURUK)</option>
                  <option value="GIZI KURANG">GIZI KURANG (GIZIKURANG)</option>
                  <option value="GIZI BAIK">GIZI BAIK (GIZIBAIK)</option>
                  <option value="BERISIKO GIZI LEBIH">BERISIKO GIZI LEBIH (BERISIKOGIZILEBIH)</option>
                  <option value="GIZI LEBIH">GIZI LEBIH (GIZILEBIH)</option>
                  <option value="OBESITAS">OBESITAS</option>
                </select>
              </div>

              <div>
                <label className="block mb-1 text-slate-700 font-bold">Status Kehamilan/Tumbuh (N/T/2T/O) <span className="text-red-500">*</span></label>
                <select
                  value={balitaStatusNto}
                  onChange={(e) => setBalitaStatusNto(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-indigo-600 focus:outline-none rounded-lg text-slate-800 text-xs font-bold"
                >
                  <option value="N">N (Naik sesuai garfik KMS)</option>
                  <option value="T">T (Tetap / Tidak Naik)</option>
                  <option value="2T">2T (Dua Kali Berturut tidak Naik)</option>
                  <option value="O">O (Obesitas / Overweight)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block mb-1 text-slate-650">Catatan Khusus Balita (Opsional)</label>
                <input
                  type="text"
                  value={balitaCatatan}
                  onChange={(e) => setBalitaCatatan(e.target.value)}
                  placeholder="Diagnosis ringkas, ASI Eksklusif orentasi..."
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

            </div>
          ) : (
            // FORM TYPE B: OTHER COHORTS FORMS (KADER, REMAJA, IBUHAMIL, USIA PRODUKTIF, LANSIA)
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-semibold text-slate-650">
              
              <div>
                <label className="block mb-1">Berat Badan Warga (BB - kg) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  placeholder="Tulis berat..."
                  value={lainBb}
                  onChange={(e) => setLainBb(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Tinggi Badan (TB - cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="40"
                  placeholder="Tulis tinggi..."
                  value={lainTb}
                  onChange={(e) => setLainTb(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Lingkar Perut (cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0 jika tidak diukur..."
                  value={lainLp}
                  onChange={(e) => setLainLp(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Lingkar Lengan Atas (LILA - cm) <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0 jika tidak diukur..."
                  value={lainLila}
                  onChange={(e) => setLainLila(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

              {/* Special instrument input fields with HABIS/ALATKOSONG options */}
              <div className="space-y-1">
                <label className="block text-slate-750 font-bold">Tekanan Darah (mmHg) <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  placeholder="e.g. 120/80 atau HABIS"
                  value={lainTd}
                  onChange={(e) => setLainTd(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-850 font-mono text-xs focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('td', 'Habis')}
                    className="flex-1 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    HABIS
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('td', 'Alat Kosong')}
                    className="flex-1 py-1 bg-slate-105 hover:bg-slate-200 text-slate-75 * text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    KOSONG
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-slate-750 font-bold">Gula Darah (mg/dL) <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  placeholder="e.g. 110 atau ALATKOSONG"
                  value={lainGds}
                  onChange={(e) => setLainGds(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-850 font-mono text-xs focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('gds', 'Habis')}
                    className="flex-1 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    HABIS
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('gds', 'Alat Kosong')}
                    className="flex-1 py-1 bg-slate-105 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    KOSONG
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-slate-750 font-bold">Asam Urat (mg/dL) <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  placeholder="e.g. 6.2"
                  value={lainAu}
                  onChange={(e) => setLainAu(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-850 font-mono text-xs focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('au', 'Habis')}
                    className="flex-1 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    HABIS
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('au', 'Alat Kosong')}
                    className="flex-1 py-1 bg-slate-105 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    KOSONG
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-slate-750 font-bold">Kolesterol (mg/dL) <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  placeholder="e.g. 195"
                  value={lainKoles}
                  onChange={(e) => setLainKoles(e.target.value)}
                  required
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-855 font-mono text-xs focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('koles', 'Habis')}
                    className="flex-1 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    HABIS
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstrumentSpecial('koles', 'Alat Kosong')}
                    className="flex-1 py-1 bg-slate-105 hover:bg-slate-200 text-slate-700 rounded font-mono text-[9px] font-bold cursor-pointer"
                  >
                    KOSONG
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="block mb-1">Catatan Tambahan (Opsional)</label>
                <input
                  type="text"
                  value={lainCatatan}
                  onChange={(e) => setLainCatatan(e.target.value)}
                  placeholder="Keluhan utama kram kaki linu, dll..."
                  className="w-full px-3 py-1.5 border border-slate-205 focus:border-indigo-600 rounded-lg text-slate-800 text-xs focus:outline-none"
                />
              </div>

            </div>
          )}

          {/* Submission and guidelines */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-slate-400">
            <p className="flex items-start gap-1 max-w-lg">
              <span className="text-amber-500 font-bold shrink-0">ℹ</span>
              <span>Pastikan seluruh kolom klinis wajib bertanda <span className="text-red-500 font-bold">*</span> telah diisi dengan akurat sesuai data pencatatan manual milik desa.</span>
            </p>
            <button
              type="submit"
              className="w-full sm:w-auto py-2.5 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow transition"
            >
              Simpan Pemeriksaan Khas
            </button>
          </div>

        </form>
      )}

    </div>
  );
}

// Simple Helper for displaying specific cohort sub-icons
function ActivityIcon({ size, className }: { size: number, className: string }) {
  return (
    <svg className={className} width={size} height={size} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
    </svg>
  );
}
