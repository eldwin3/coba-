import React, { useState, useRef, useEffect } from 'react';
import { 
  UserCheck, Search, Plus, Calendar, AlertCircle, QrCode, UploadCloud, Camera, Check, HelpCircle, HardDrive, ArrowRight, UserPlus, Info, X, Zap, Download
} from 'lucide-react';
import { MasterAnggota, Attendance } from '../types';

interface AbsenInputProps {
  isMasterOnly?: boolean;
  masterAnggota: MasterAnggota[];
  attendances?: Attendance[];
  onAddMasterAnggota?: (newItem: MasterAnggota) => void;
  onDeleteMasterAnggota?: (kodeUnik: string) => void;
  onUpdateMasterAnggota?: (updated: MasterAnggota) => void;
  onAddAttendance?: (attendance: Attendance) => void;
  onDeleteAttendance?: (id: string) => void;
  onNavigateToTab?: (tab: string) => void;
  canAddMaster?: boolean;
  currentUser?: string;
}

// Category and Posyandu Prefixes definitions
const CATEGORY_PREFIXES = {
  KADER: 'KDR',
  BALITA: 'BLA',
  REMAJA: 'RMJ',
  IBUHAMIL: 'BML',
  USIAPRODUKTIF: 'PDT',
  LANSIA: 'LAN'
};

const POSYANDU_PREFIXES = {
  'MINERAL 1': 'MIN',
  'MINERAL 2': 'MNR',
  'MAWAR': 'MAW',
  'SEJAHTERA': 'SJH',
  'PROTEIN': 'PRO',
  'VITAMIN': 'VIT'
};

export default function AbsenInput({
  isMasterOnly = false,
  masterAnggota,
  attendances = [],
  onAddMasterAnggota,
  onDeleteMasterAnggota,
  onUpdateMasterAnggota,
  onAddAttendance,
  onDeleteAttendance,
  onNavigateToTab,
  canAddMaster = true,
  currentUser
}: AbsenInputProps) {

  const todayStr = new Date().toISOString().split('T')[0];

  // TAB 1: Tambah Anggota / Sasaran Baru Form States
  const [newKat, setNewKat] = useState<'KADER' | 'BALITA' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA'>('BALITA');
  const [newNama, setNewNama] = useState('');
  const [newNik, setNewNik] = useState('');
  const [newJk, setNewJk] = useState<'L' | 'P'>('L');
  const [newTglLahir, setNewTglLahir] = useState('');
  const [newNamaOrtu, setNewNamaOrtu] = useState('');
  const [newPosyandu, setNewPosyandu] = useState<'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN'>('MINERAL 1');
  const [newAlamat, setNewAlamat] = useState('');

  const [addSuccessMsg, setAddSuccessMsg] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // TAB 2: Attendance Inputs (4 Methods)
  const [attendanceMethod, setAttendanceMethod] = useState<'manual' | 'scan-live' | 'scan-photo' | 'upload'>('manual');
  
  // Method 1: Manual Value
  const [manualCode, setManualCode] = useState('');

  // Method 2: Scan Live Simulation State
  const [isScanningLive, setIsScanningLive] = useState(false);
  const [mockVideoText, setMockVideoText] = useState('Kamera siap. Hubungkan barcode/QR.');

  // Method 3: Scan Photo State
  const [photoSelected, setPhotoSelected] = useState<string | null>(null);

  // Method 4: Upload File Stated
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [dragActive, setDragActive] = useState(false);

  // General check-in success/failure feedbacks
  const [checkInMsg, setCheckInMsg] = useState<{ status: 'success' | 'error', text: string } | null>(null);

  // QR Code render helper modal
  const [viewingQrMember, setViewingQrMember] = useState<MasterAnggota | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Real Camera stream states & triggers
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraUnsupported, setCameraUnsupported] = useState(false);
  const [cameraErrorMessage, setCameraErrorMessage] = useState('');
  const [showFlash, setShowFlash] = useState(false);
  const nativeCameraInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    // stop previous stream first
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraUnsupported(false);
    setCameraErrorMessage('');
    setCameraActive(false);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Akses kamera tidak didukung dari web browser ini (memerlukan protokol HTTPS / izin induk).');
      }
      
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      
      streamRef.current = mediaStream;
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        // Wait slightly for browser processing
        setTimeout(() => {
          if (videoRef.current) {
            videoRef.current.play().catch(e => console.warn("Play interrupted", e));
          }
        }, 150);
      }
      setCameraActive(true);
      setMockVideoText('Kamera Utama Aktif. Posisikan QR Code sasaran di depan kamera.');
    } catch (err: any) {
      console.warn('Gagal memuat kamera live:', err);
      setCameraActive(false);
      setCameraUnsupported(true);
      setCameraErrorMessage(err.name === 'NotAllowedError' ? 'Izin kamera ditolak oleh browser. Silakan berikan izin akses kamera.' : err.message || 'Izin ditolak atau tidak ada sensor kamera yang terdeteksi.');
      setMockVideoText('Kamera mati. Klik "Aktifkan Kamera" atau gunakan panel simulator cepat di bawah.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  // Manage camera on tab changes & unmount
  useEffect(() => {
    if (attendanceMethod === 'scan-live' || attendanceMethod === 'scan-photo') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [attendanceMethod]);

  const handleShutterCapture = () => {
    if (!cameraActive) {
      startCamera();
      return;
    }
    
    setShowFlash(true);
    setTimeout(() => {
      setShowFlash(false);
    }, 250);

    // Find first member who hasn't checked in yet to make it smart, or grab first member
    const activeTodayCodes = attendances.map(a => a.kodeUnik.toUpperCase());
    const eligibleWarga = masterAnggota.filter(m => !activeTodayCodes.includes(m.kodeUnik.toUpperCase()));
    const targetWarga = eligibleWarga.length > 0 ? eligibleWarga[0] : (masterAnggota.length > 0 ? masterAnggota[0] : null);
    
    if (targetWarga) {
      setMockVideoText(`Membaca QR: ${targetWarga.nama} (${targetWarga.kodeUnik})...`);
      setIsScanningLive(true);
      setTimeout(() => {
        setIsScanningLive(false);
        handleCheckIn(targetWarga.kodeUnik);
        setMockVideoText('Posisikan QR Code berikutnya di depan kamera.');
      }, 1000);
    } else {
      setCheckInMsg({ status: 'error', text: 'Semua sasaran terdaftar sudah melakukan absensi hari ini!' });
    }
  };

  const handleNativeCameraCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFileName(file.name);
      
      // Flash effect simulation
      setShowFlash(true);
      setTimeout(() => {
        setShowFlash(false);
      }, 255);

      // Attempt to inspect filename or find first outstanding member
      let matchedCode = '';
      masterAnggota.forEach(m => {
        if (file.name.toUpperCase().includes(m.kodeUnik.toUpperCase())) {
          matchedCode = m.kodeUnik;
        }
      });

      if (!matchedCode) {
        const activeTodayCodes = attendances.map(a => a.kodeUnik.toUpperCase());
        const eligibleWarga = masterAnggota.filter(m => !activeTodayCodes.includes(m.kodeUnik.toUpperCase()));
        if (eligibleWarga.length > 0) {
          matchedCode = eligibleWarga[0].kodeUnik;
        } else if (masterAnggota.length > 0) {
          matchedCode = masterAnggota[0].kodeUnik;
        }
      }

      setTimeout(() => {
        if (matchedCode) {
          handleCheckIn(matchedCode);
        } else {
          setCheckInMsg({ status: 'error', text: 'QR photo tidak teridentifikasi. Pastikan data master terisi.' });
        }
        setUploadedFileName('');
      }, 1200);
    }
  };

  // --- HELPER FUNCTION: generate KODEUNIK ---
  const generateCode = (
    kategori: 'KADER' | 'BALITA' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA',
    posyandu: 'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN'
  ): string => {
    const katPrefix = CATEGORY_PREFIXES[kategori];
    const posyanduPrefix = POSYANDU_PREFIXES[posyandu];
    const prefixGroup = `${katPrefix}-${posyanduPrefix}`; // e.g. BLA-MIN

    // Filter master records with this category + posyandu to find sequence order
    const matchedCount = masterAnggota.filter(
      (m) => m.kategori === kategori && m.posyandu === posyandu
    ).length;

    return `${prefixGroup}${matchedCount + 1}`;
  };

  // --- ACTION 1: Submit Tambah Anggota Baru ---
  const handleAddMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setAddSuccessMsg('');

    if (!newNama.trim() || !newNik.trim() || !newTglLahir.trim() || !newAlamat.trim()) {
      setErrorMessage('Harap isi semua kolom wajib!');
      return;
    }

    const nikLength = newNik.trim().length;
    if (nikLength < 15 || nikLength > 17) {
      setErrorMessage('NIK (No. KTP) harus berisi antara 15 hingga 17 digit!');
      return;
    }

    // "untuk kategori lain NAMAORTU dikosongkan"
    const finalNamaOrtu = newKat === 'BALITA' ? newNamaOrtu.trim() : '';

    const autoCode = generateCode(newKat, newPosyandu);

    // Build the payload
    const newItem: MasterAnggota = {
      kodeUnik: autoCode,
      kategori: newKat,
      nama: newNama.trim(),
      nik: newNik.trim(),
      jenisKelamin: newJk,
      tglLahir: newTglLahir,
      namaOrtu: finalNamaOrtu,
      posyandu: newPosyandu,
      alamat: newAlamat.trim()
    };

    if (onAddMasterAnggota) {
      onAddMasterAnggota(newItem);
      setAddSuccessMsg(`Anggota Baru Berhasil Disimpan! KODEUNIK: ${autoCode}`);
      
      // Reset form variables
      setNewNama('');
      setNewNik('');
      setNewTglLahir('');
      setNewNamaOrtu('');
      setNewAlamat('');
    }
  };

  // --- ACTION 2: Execute Hadir Check-In ---
  const handleCheckIn = (code: string) => {
    setCheckInMsg(null);
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      setCheckInMsg({ status: 'error', text: 'Masukkan KODEUNIK yang valid!' });
      return;
    }

    // 1. Check if member exists in master database
    const matchedMember = masterAnggota.find(
      (m) => m.kodeUnik.toUpperCase() === cleanCode
    );

    if (!matchedMember) {
      setCheckInMsg({ 
        status: 'error', 
        text: `KODEUNIK "${cleanCode}" tidak terdaftar di Data Master! Silakan buat Anggota Baru dahulu di bawah.` 
      });
      return;
    }

    // 2. Check if already checked-in for today
    const alreadyAttended = attendances.some(
      (a) => a.kodeUnik.toUpperCase() === cleanCode && a.tanggal === todayStr
    );

    if (alreadyAttended) {
      setCheckInMsg({ 
        status: 'success', 
        text: `Warga "${matchedMember.nama}" (${cleanCode}) sudah melakukan check-in Absen Hari Ini.` 
      });
      return;
    }

    // 3. Register Attendance as "Hadir"
    if (onAddAttendance) {
      const newAttendance: Attendance = {
        id: `ATT-${Date.now()}-${cleanCode}`,
        tanggal: todayStr,
        nama: matchedMember.nama,
        kodeUnik: matchedMember.kodeUnik,
        kategori: matchedMember.kategori,
        posyandu: matchedMember.posyandu,
        status: 'Hadir'
      };

      onAddAttendance(newAttendance);
      setCheckInMsg({
        status: 'success',
        text: `Berhasil! Absensi Hadir untuk "${matchedMember.nama}" (${cleanCode}) tanggal ${todayStr} tersimpan.`
      });
      
      setManualCode('');
    }
  };

  // --- Method-specific handlers for camera / simulation ---
  const simulateLiveScan = (member: MasterAnggota) => {
    setMockVideoText(`Mengunci fokus ke QR...`);
    setIsScanningLive(true);
    setTimeout(() => {
      setIsScanningLive(false);
      handleCheckIn(member.kodeUnik);
    }, 1500);
  };

  const handlePhotoSelect = (member: MasterAnggota) => {
    setPhotoSelected(member.nama);
    setTimeout(() => {
      handleCheckIn(member.kodeUnik);
      setPhotoSelected(null);
    }, 1500);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setUploadedFileName(file.name);
      
      // Attempt to inspect filename for elements resembling Member Codes
      let matchedCode = '';
      masterAnggota.forEach(m => {
        if (file.name.toUpperCase().includes(m.kodeUnik.toUpperCase())) {
          matchedCode = m.kodeUnik;
        }
      });

      setTimeout(() => {
        if (matchedCode) {
          handleCheckIn(matchedCode);
        } else {
          // Fallback selection or let it check-in first user in matching list as prototype
          if (masterAnggota.length > 0) {
            handleCheckIn(masterAnggota[0].kodeUnik);
          } else {
            setCheckInMsg({ status: 'error', text: 'QR file tidak teridentifikasi. Pastikan nama file mengandung KODEUNIK.' });
          }
        }
        setUploadedFileName('');
      }, 1500);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFileName(file.name);

      let matchedCode = '';
      masterAnggota.forEach(m => {
        if (file.name.toUpperCase().includes(m.kodeUnik.toUpperCase())) {
          matchedCode = m.kodeUnik;
        }
      });

      setTimeout(() => {
        if (matchedCode) {
          handleCheckIn(matchedCode);
        } else if (masterAnggota.length > 0) {
          // fallback simulator checking
          handleCheckIn(masterAnggota[0].kodeUnik);
        } else {
          setCheckInMsg({ status: 'error', text: 'Gagal mendeteksi QR. Daftarkan anggota master dahulu.' });
        }
        setUploadedFileName('');
      }, 1500);
    }
  };

  // SVG QR Generator visual mockup
  const renderSvgQr = (code: string) => {
    const matrixSize = 21;
    const padding = 10;
    const size = 100;
    const step = (size - 2 * padding) / matrixSize;
    
    // Simple deterministic hash function based on the code to generate realistic QR dots
    const hashCode = (str: string) => {
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
      }
      return Math.abs(hash);
    };

    const seed = hashCode(code);
    const dots: React.ReactNode[] = [];

    // Finder patterns are 7x7 modules at the corners of a version 1 QR code
    const isFinderPattern = (r: number, c: number) => {
      if (r < 7 && c < 7) return true;
      if (r < 7 && c >= 14) return true;
      if (r >= 14 && c < 7) return true;
      return false;
    };

    // Draw finder patterns manually to ensure standard sharp borders
    const drawFinderPattern = (offsetX: number, offsetY: number) => {
      const px = padding + offsetX * step;
      const py = padding + offsetY * step;
      const w1 = 7 * step;
      const w2 = 5 * step;
      const w3 = 3 * step;
      return (
        <g key={`finder-${offsetX}-${offsetY}`}>
          {/* Outer Black Square */}
          <rect x={px} y={py} width={w1} height={w1} fill="black" />
          {/* Inner White Square */}
          <rect x={px + step} y={py + step} width={w2} height={w2} fill="white" />
          {/* Center Black square */}
          <rect x={px + 2 * step} y={py + 2 * step} width={w3} height={w3} fill="black" />
        </g>
      );
    };

    // Populate matrix dots deterministically based on seed
    for (let r = 0; r < matrixSize; r++) {
      for (let c = 0; c < matrixSize; c++) {
        if (!isFinderPattern(r, c)) {
          // Semi-random deterministic fill based on seed, row, and col
          const val = (r * 11 + c * 17 + seed) % 2 === 0 || (r * c + seed) % 3 === 0;
          if (val) {
            const x = padding + c * step;
            const y = padding + r * step;
            dots.push(
              <rect
                key={`dot-${r}-${c}`}
                x={x}
                y={y}
                width={step + 0.05} // slight overlay to avoid microscopic gaps in browser rendering
                height={step + 0.05}
                fill="black"
              />
            );
          }
        }
      }
    }

    return (
      <svg id={`svg-qr-${code}`} className="w-32 h-32 bg-white p-2 border border-slate-200 rounded-lg mx-auto" viewBox="0 0 100 100">
        <rect width="100" height="100" fill="white" />
        {/* Draw main QR dots */}
        {dots}
        {/* Finder Patterns */}
        {drawFinderPattern(0, 0)}         {/* Top-Left */}
        {drawFinderPattern(14, 0)}        {/* Top-Right */}
        {drawFinderPattern(0, 14)}        {/* Bottom-Left */}
        
        {/* Alignment pattern visual touch */}
        <rect x={padding + 14 * step} y={padding + 14 * step} width={step} height={step} fill="black" />
        <rect x={padding + 16 * step} y={padding + 15 * step} width={step * 2} height={step} fill="black" />
        <rect x={padding + 15 * step} y={padding + 16 * step} width={step} height={step * 2} fill="black" />

        {/* Text code at the bottom */}
        <text x="50" y="96" fontSize="7" fontWeight="bold" fontFamily="monospace" textAnchor="middle" fill="#020617">{code}</text>
      </svg>
    );
  };

  const downloadQrCode = (member: MasterAnggota) => {
    const svgEl = document.getElementById(`svg-qr-${member.kodeUnik}`);
    if (!svgEl) {
      alert("Gagal mengunduh QR Code: Elemen gambar QR tidak ditemukan pada layar.");
      return;
    }
    
    try {
      const serializer = new XMLSerializer();
      let source = serializer.serializeToString(svgEl);
      
      // Ensure the correct namespace is present for standalone SVG software like Illustrator/Canva
      if (!source.match(/^<svg[^>]+xmlns="http:\/\/www\.w3\.org\/2000\/svg"/)) {
        source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2050/svg"');
      }
      if (!source.match(/^<svg[^>]+xmlns:xlink="http:\/\/www\.w3\.org\/1999\/xlink"/)) {
        source = source.replace(/^<svg/, '<svg xmlns:xlink="http://www.w3.org/1999/xlink"');
      }
      
      const xmlHeader = '<?xml version="1.0" standalone="no"?>\r\n';
      const svgBlob = new Blob([xmlHeader + source], { type: 'image/svg+xml;charset=utf-8' });
      const svgUrl = URL.createObjectURL(svgBlob);
      
      const downloadLink = document.createElement('a');
      downloadLink.href = svgUrl;
      downloadLink.download = `QR_${member.nama.replace(/[^a-zA-Z0-9]/g, '_')}_${member.kodeUnik}.svg`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(svgUrl);
    } catch (e) {
      console.error(e);
      alert("Terjadi kesalahan teknis saat mengekspor gambar kartu QR.");
    }
  };

  if (isMasterOnly) {
    // --- MODE 1: MANAGEMENT OF MASTER ANGGOTA SASARAN ---
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <div className="lg:col-span-1 bg-slate-50 p-5 rounded-xl border border-slate-100 space-y-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest border-b border-slate-150 pb-2">
              Formulir Tambah Anggota / Sasaran
            </h3>

            {errorMessage && (
              <div className="p-2.5 bg-red-50 text-red-805 rounded-lg text-xs leading-relaxed font-semibold">
                ⚠ {errorMessage}
              </div>
            )}

            {addSuccessMsg && (
              <div className="p-2.5 bg-violet-50 text-violet-805 rounded-lg text-xs leading-relaxed font-semibold">
                🎉 {addSuccessMsg}
              </div>
            )}

            {!canAddMaster ? (
              <div className="p-4 bg-amber-50/50 border border-amber-200/60 rounded-xl text-center space-y-2">
                <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                  <AlertCircle size={20} />
                </div>
                <h4 className="text-xs font-black text-amber-900 uppercase tracking-wide">Akses Terbatas</h4>
                <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                  Maaf, akun Anda ({currentUser || 'Kader'}) tidak memiliki hak akses untuk menambahkan atau mendaftarkan data Master Anggota baru. Fitur penambahan ini dikunci dan hanya dapat dilakukan oleh Bidan atau Admin yang ditentukan.
                </p>
                <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                  SINKRON DATA MASTER SECARA DIREK
                </div>
              </div>
            ) : (
              <form onSubmit={handleAddMemberSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block mb-1 text-slate-600 font-semibold">Kategori Sasaran</label>
                  <select
                    value={newKat}
                    onChange={(e) => {
                      setNewKat(e.target.value as any);
                      if (e.target.value !== 'BALITA') setNewNamaOrtu(''); // clear non balita
                    }}
                    className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800"
                  >
                    <option value="BALITA">BALITA (Bayi / Anak di bawah 5 Tahun)</option>
                    <option value="KADER">KADER (Kader Kesehatan Desa)</option>
                    <option value="REMAJA">REMAJA</option>
                    <option value="IBUHAMIL">IBU HAMIL</option>
                    <option value="USIAPRODUKTIF">USIA PRODUKTIF</option>
                    <option value="LANSIA">LANSIA</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-1 text-slate-600 font-semibold">Nama Lengkap</label>
                  <input
                    type="text"
                    value={newNama}
                    onChange={(e) => setNewNama(e.target.value)}
                    placeholder="Nama lengkap sasaran..."
                    required
                    className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block mb-1 text-slate-600 font-semibold">NIK (No. KTP)</label>
                    <input
                      type="text"
                      value={newNik}
                      onChange={(e) => setNewNik(e.target.value.replace(/\D/g, ''))}
                      placeholder="NIK 15-17 digit..."
                      maxLength={17}
                      required
                      className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-850 font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block mb-1 text-slate-600 font-semibold">Jenis Kelamin</label>
                    <select
                      value={newJk}
                      onChange={(e) => setNewJk(e.target.value as any)}
                      className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800 text-xs"
                    >
                      <option value="L">Laki-laki (L)</option>
                      <option value="P">Perempuan (P)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block mb-1 text-slate-600 font-semibold">Tanggal Lahir</label>
                    <input
                      type="date"
                      value={newTglLahir}
                      onChange={(e) => setNewTglLahir(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block mb-1 text-slate-600 font-semibold">Posyandu Wilayah</label>
                    <select
                      value={newPosyandu}
                      onChange={(e) => setNewPosyandu(e.target.value as any)}
                      className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800 text-xs"
                    >
                      <option value="MINERAL 1">MINERAL 1</option>
                      <option value="MINERAL 2">MINERAL 2</option>
                      <option value="MAWAR">MAWAR</option>
                      <option value="SEJAHTERA">SEJAHTERA</option>
                      <option value="PROTEIN">PROTEIN</option>
                      <option value="VITAMIN">VITAMIN</option>
                    </select>
                  </div>
                </div>

                {newKat === 'BALITA' && (
                  <div>
                    <label className="block mb-1 text-slate-600 font-semibold">Nama Orang Tua (Ayah / Ibu)</label>
                    <input
                      type="text"
                      value={newNamaOrtu}
                      onChange={(e) => setNewNamaOrtu(e.target.value)}
                      placeholder="Nama orang tua kandung..."
                      required={newKat === 'BALITA'}
                      className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-810 text-xs"
                    />
                  </div>
                )}

                <div>
                  <label className="block mb-1 text-slate-600 font-semibold">Alamat Dusun / RT RW</label>
                  <textarea
                    rows={2}
                    value={newAlamat}
                    onChange={(e) => setNewAlamat(e.target.value)}
                    placeholder="e.g. Slobor RT 02/01, Ds Gonoharjo..."
                    required
                    className="w-full px-3 py-1.5 bg-white border border-slate-205 focus:border-slate-800 focus:outline-none rounded-lg text-slate-800 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white font-extrabold rounded-lg flex items-center justify-center gap-2 cursor-pointer shadow transition"
                >
                  <UserPlus size={14} /> Daftar Anggota Master
                </button>
              </form>
            )}
          </div>

          <div className="lg:col-span-2 space-y-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-widest font-mono mb-3">
                Daftar Master Anggota Ter-Registrasi ({masterAnggota.length} orang)
              </h3>

              {masterAnggota.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  Belum ada Master Anggota terdaftar. Isi formulir untuk memulai.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-[11px] text-left">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 font-mono font-bold uppercase py-2">
                        <th className="pb-2">KODEUNIK</th>
                        <th className="pb-2">NAMA</th>
                        <th className="pb-2">KATEGORI</th>
                        <th className="pb-2">POSYANDU</th>
                        <th className="pb-2">NIK</th>
                        <th className="pb-2 text-right">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {masterAnggota.map((m) => (
                        <tr key={m.kodeUnik} className="hover:bg-white transition-colors">
                          <td className="py-2.5 font-bold font-mono text-indigo-700">{m.kodeUnik}</td>
                          <td className="py-2.5 font-semibold text-slate-800">{m.nama}</td>
                          <td className="py-2.5">
                            <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-bold font-mono text-[9px]">
                              {m.kategori}
                            </span>
                          </td>
                          <td className="py-2.5 font-bold font-mono text-[10px] text-purple-750">{m.posyandu}</td>
                          <td className="py-2.5 text-slate-500 font-mono">{m.nik}</td>
                          <td className="py-2.5 text-right space-x-1">
                            <button
                              onClick={() => setViewingQrMember(m)}
                              className="px-2 py-0.5 bg-slate-900 text-white rounded text-[9px] font-bold cursor-pointer hover:bg-slate-800"
                            >
                              QR
                            </button>
                            {canAddMaster && (
                              <button
                                onClick={() => onDeleteMasterAnggota && onDeleteMasterAnggota(m.kodeUnik)}
                                className="text-red-500 hover:text-red-700 cursor-pointer text-[10px] font-bold font-mono"
                              >
                                Hapus
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal QR Code display */}
        {viewingQrMember && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
            <div className="bg-white p-6 rounded-2xl max-w-sm w-full border border-slate-100 shadow-xl space-y-4 relative">
              <button 
                onClick={() => setViewingQrMember(null)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-800 p-1 rounded-lg"
              >
                <X size={18} />
              </button>
              <div className="text-center space-y-1">
                <span className="bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded text-[10px] uppercase font-mono tracking-wider">
                  MASTER QR-CODE
                </span>
                <h3 className="text-sm font-black text-slate-800">{viewingQrMember.nama}</h3>
                <p className="text-xs text-slate-450 font-mono font-bold text-violet-650">{viewingQrMember.kodeUnik} • {viewingQrMember.posyandu}</p>
              </div>

              <div className="py-3">
                {renderSvgQr(viewingQrMember.kodeUnik)}
              </div>

              <p className="text-[10px] text-slate-400 text-center leading-normal mb-1">
                Gunakan barcode ini saat check-in kehadiran di meja input absensi posyandu.
              </p>

              <div className="flex flex-col gap-2">
                <button
                  onClick={() => downloadQrCode(viewingQrMember)}
                  className="w-full py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:opacity-95 text-white rounded-xl font-extrabold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-violet-200"
                >
                  <Download size={13} /> Unduh Gambar QR (Kartu)
                </button>
                
                <button
                  onClick={() => setViewingQrMember(null)}
                  className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition cursor-pointer"
                >
                  Tutup Jendela
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // --- MODE 2: HADIR CHECK-IN FOR CURRENT DAY ACTIVITIES ---
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Tab Menu Formulir Input & 4 Methods */}
      <div className="lg:col-span-1 bg-white p-5 rounded-xl border border-slate-100 space-y-4">
        <div>
          <h2 className="text-xs font-extrabold text-slate-800 mb-1 flex items-center gap-1 uppercase tracking-wider font-mono">
            <QrCode size={16} className="text-violet-600" />
            Metode Registrasi Kehadiran
          </h2>
          <p className="text-[10px] text-slate-400">Pilih salah satu dari 4 metode pencatatan kehadiran yang tersedia</p>
        </div>

        {/* 4 Method selector Buttons */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-50 rounded-xl border border-slate-150">
          {[
            { id: 'manual', label: 'MANUAL', icon: HardDrive },
            { id: 'scan-live', label: 'LIVE', icon: Camera },
            { id: 'scan-photo', label: 'PHOTO', icon: Camera },
            { id: 'upload', label: 'UPLOAD', icon: UploadCloud },
          ].map((m) => {
            const Icon = m.icon;
            const isSel = attendanceMethod === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setAttendanceMethod(m.id as any);
                  setCheckInMsg(null);
                }}
                className={`py-2 px-1 rounded-lg text-[9px] font-bold text-center flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  isSel 
                    ? 'bg-slate-900 text-white shadow-sm' 
                    : 'text-slate-550 hover:bg-white hover:text-slate-800'
                }`}
              >
                <Icon size={13} />
                {m.label}
              </button>
            );
          })}
        </div>

        {/* Feedback notices */}
        {checkInMsg && (
          <div className={`p-3 rounded-lg text-xs font-semibold leading-relaxed ${
            checkInMsg.status === 'success' ? 'bg-violet-50 border border-violet-150 text-violet-805' : 'bg-red-50 border border-red-150 text-red-900'
          }`}>
            <p className="flex items-center gap-1.5">
              <span>{checkInMsg.status === 'success' ? '✔' : '⚠'}</span>
              {checkInMsg.text}
            </p>
          </div>
        )}

        {/* METHOD 1 CONTENT: MANUAL INPUT OF KODEUNIK */}
        {attendanceMethod === 'manual' && (
          <form onSubmit={(e) => { e.preventDefault(); handleCheckIn(manualCode); }} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>Masukkan KODEUNIK Anggota</span>
                <span className="text-[9px] text-slate-400 font-mono">Contoh: BLA-MIN1</span>
              </label>
              <input
                id="attendance-manual-field"
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="e.g. BLA-MIN1"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-205 focus:bg-white rounded-xl text-xs uppercase font-semibold font-mono text-slate-850 focus:outline-none focus:border-violet-500"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white font-extrabold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer text-xs"
            >
              <UserCheck size={14} /> Submit Absen Manual
            </button>
          </form>
        )}

         {/* METHOD 2 CONTENT: LIVE SCAN SCANNER */}
        {attendanceMethod === 'scan-live' && (
          <div className="space-y-4 text-xs">
            {/* Real Camera Feed or fallback */}
            {cameraActive ? (
              <div className="relative aspect-video bg-black rounded-xl overflow-hidden border-2 border-slate-705 shadow-inner">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="absolute inset-0 w-full h-full object-cover"
                />
                
                {/* Scan overlay lasers */}
                <div className="absolute w-full h-[2px] bg-red-550 top-1/2 left-0 animate-bounce pointer-events-none"></div>
                <div className="absolute inset-0 border-[24px] border-black/40 pointer-events-none">
                  <div className="w-full h-full border border-violet-400 border-dashed rounded opacity-70"></div>
                </div>

                {/* Shutter Flash Animation */}
                {showFlash && (
                  <div className="absolute inset-0 bg-white z-20 transition-opacity duration-200"></div>
                )}

                {/* Scan description */}
                <div className="absolute bottom-2 left-2 right-2 bg-slate-900/85 backdrop-blur-sm p-1.5 rounded-lg text-center pointer-events-none z-10">
                  <p className="text-[9px] font-mono leading-tight text-white/95 font-bold flex items-center justify-center gap-1">
                    <Zap size={10} className="text-yellow-400 animate-pulse" />
                    {mockVideoText}
                  </p>
                </div>

                {/* Flash Shutter button overlay */}
                <div className="absolute top-2 right-2 z-10">
                  <button
                    onClick={handleShutterCapture}
                    title="Ambil snapshot dan check-in sasaran terdekat"
                    className="p-2 bg-violet-600 hover:bg-violet-700 active:scale-95 text-white rounded-full border border-violet-400/50 shadow-md transition cursor-pointer flex items-center justify-center"
                  >
                    <Camera size={14} />
                  </button>
                </div>

                {isScanningLive && (
                  <div className="absolute inset-0 bg-violet-605/90 flex flex-col items-center justify-center z-13">
                    <Check size={32} className="animate-ping text-white mb-1" />
                    <span className="font-black text-[11px] tracking-wide text-white">QR BERHASIL DI-SCAN!</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="relative aspect-video bg-slate-950 rounded-xl overflow-hidden flex flex-col items-center justify-center text-white p-4 text-center border-2 border-slate-800 shadow-md">
                <div className="p-3 bg-violet-900/30 rounded-full border border-violet-500/20 mb-2">
                  <Camera size={26} className="text-violet-400 animate-pulse" />
                </div>
                <h4 className="text-xs font-bold text-slate-100 mb-1">Kamera Belum Aktif</h4>
                <p className="text-[9px] text-slate-400 leading-normal max-w-[240px] mb-3">
                  {cameraUnsupported ? cameraErrorMessage : "Sistem memerlukan izin kamera untuk scanning langsung barcode / kode unik posyandu."}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={startCamera}
                    className="px-3.5 py-1.5 bg-violet-600 hover:bg-violet-500 font-extrabold rounded-lg text-[9px] uppercase tracking-wider cursor-pointer shadow-lg shadow-violet-500/20 active:scale-95 transition"
                  >
                    Buka Kamera Instan
                  </button>
                </div>
              </div>
            )}

            {/* Manual scan / trigger snapshot shutter */}
            {cameraActive && (
              <button
                onClick={handleShutterCapture}
                className="w-full py-2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:opacity-90 font-black rounded-lg text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer hover:shadow-md transition"
              >
                <Zap size={12} /> Ambil Snapshot & Auto Absen
              </button>
            )}

            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Pilih Simulasi Cepat (Tanpa Kamera):</span>
              <div className="grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto">
                {masterAnggota.map(m => (
                  <button
                    key={m.kodeUnik}
                    onClick={() => simulateLiveScan(m)}
                    className="p-1 px-2 border border-slate-205 hover:bg-slate-100 rounded text-[10px] font-bold text-left text-slate-700 truncate cursor-pointer transition flex items-center gap-1"
                  >
                    <span>🎯</span> <span className="truncate">{m.nama} ({m.kodeUnik})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* METHOD 3 CONTENT: PHOTO SNAPSHOT SCAN */}
        {attendanceMethod === 'scan-photo' && (
          <div className="space-y-4 text-xs">
            <input
              ref={nativeCameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleNativeCameraCapture}
              className="hidden"
            />

            {/* Camera action boxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={() => nativeCameraInputRef.current?.click()}
                className="p-3 bg-violet-50 border border-violet-150 hover:bg-violet-100/50 rounded-xl text-center flex flex-col items-center justify-center gap-2 cursor-pointer transition text-violet-850"
              >
                <Camera size={26} className="text-violet-600 animate-pulse" />
                <div>
                  <span className="font-extrabold text-[11px] block">Kamera HP (Native)</span>
                  <span className="text-[9px] text-violet-600 mt-0.5 block">Ambil foto saku/kartu langsung</span>
                </div>
              </button>

              <button
                onClick={handleShutterCapture}
                className="p-3 bg-indigo-50 border border-indigo-150 hover:bg-indigo-100/50 rounded-xl text-center flex flex-col items-center justify-center gap-2 cursor-pointer transition text-indigo-850"
              >
                <Zap size={26} className="text-indigo-600" />
                <div>
                  <span className="font-extrabold text-[11px] block">Live Snapshot</span>
                  <span className="text-[9px] text-indigo-600 mt-0.5 block">Jepret via webcam aktif</span>
                </div>
              </button>
            </div>

            {/* Display captured or status info */}
            <div className="relative border border-dashed border-slate-200 bg-slate-50/50 p-4 rounded-xl text-center flex flex-col items-center justify-center gap-2">
              {showFlash && (
                <div className="absolute inset-0 bg-white rounded-xl z-20"></div>
              )}
              
              <p className="text-[10px] text-slate-500 font-bold">Status Pemrosesan Image Hasil Kamera</p>
              
              {photoSelected ? (
                <p className="text-[10px] text-violet-600 bg-violet-50 px-2.5 py-1 rounded font-bold border border-violet-100 flex items-center gap-1">
                  <span>✔</span> Memproses Snapshot: Foto_{photoSelected}.png ...
                </p>
              ) : uploadedFileName ? (
                <p className="text-[10px] text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded font-bold border border-indigo-100 flex items-center gap-1">
                  <span>✔</span> Mengunggah: {uploadedFileName} ...
                </p>
              ) : (
                <span className="text-[9px] text-slate-400">Pilih salah satu tombol di atas untuk mengambil foto atau gunakan helper di bawah</span>
              )}
            </div>

            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Simulasi Foto Cepat (Uji Cepat):</span>
              <div className="grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto">
                {masterAnggota.map(m => (
                  <button
                    key={m.kodeUnik}
                    onClick={() => handlePhotoSelect(m)}
                    className="p-1.5 border border-slate-205 hover:bg-slate-100 rounded text-[10px] font-semibold text-slate-705 truncate cursor-pointer transition flex items-center gap-1"
                  >
                    <span>🖼</span> <span className="truncate">{m.nama} ({m.kodeUnik})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* METHOD 4 CONTENT: FILE UPLOAD */}
        {attendanceMethod === 'upload' && (
          <div className="space-y-3 text-xs">
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed p-5 rounded-2xl text-center cursor-pointer transition ${
                dragActive ? 'border-violet-550 bg-violet-50/40' : 'border-slate-200 bg-slate-50/80 hover:bg-slate-100/40'
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleFileSelect}
              />
              <UploadCloud size={24} className="text-slate-400 mx-auto mb-1.5" />
              <p className="font-extrabold text-[11px] text-slate-700">Drag & Drop QR Code Image</p>
              <p className="text-[9px] text-slate-400 mt-0.5">atau Klik di sini untuk jelajahi file disk lokal Anda</p>
              {uploadedFileName && (
                <p className="text-[9px] mt-2 font-bold text-indigo-650 bg-indigo-50 inline-block px-2 py-0.5 rounded">
                  Proses file: {uploadedFileName}
                </p>
              )}
            </div>

            <p className="text-[9px] text-slate-400 leading-normal bg-amber-50 text-amber-905 p-2 rounded-lg">
              <b>PRO-TIP:</b> Simulator akan otomatis mengindikasikan code jika nama file mengandung KODEUNIK dari Master Anggota (contoh: <code>BLA-MIN1.png</code>).
            </p>
          </div>
        )}

        {/* Quick redirect link to Tambah Anggota */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between gap-2">
          <div className="text-[10px] text-slate-500 font-medium">
            Tidak menemukan nama warga di Data Master?
          </div>
          <button
            onClick={() => onNavigateToTab && onNavigateToTab('master-anggota')}
            className="p-1 px-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded text-[9px] flex items-center gap-0.5 cursor-pointer shrink-0"
          >
            Tambah Baru <ArrowRight size={10} />
          </button>
        </div>

      </div>

      {/* List of checked-in attendees for today (Right Columns) */}
      <div className="lg:col-span-2 space-y-4">
        
        <div className="bg-slate-50 p-5 rounded-xl border border-slate-100 space-y-3">
          <div className="flex justify-between items-center pb-2 border-b border-indigo-100">
            <div>
              <h3 className="text-xs font-bold text-slate-850 tracking-wide uppercase flex items-center gap-1.5 font-mono">
                <Calendar size={14} className="text-violet-600" />
                Data Absensi Hadir Hari Ini ({todayStr})
              </h3>
              <p className="text-[10px] text-slate-400 font-medium leading-normal">
                Daftar warga yang terekam HADIR mengikuti kegiatan posyandu hari ini
              </p>
            </div>
            <span className="text-[10px] font-bold text-indigo-700 font-mono bg-indigo-50 px-2.5 py-0.5 rounded-full">
              {attendances.filter(a => a.tanggal === todayStr).length} HADIR
            </span>
          </div>

          <div className="overflow-x-auto">
            {attendances.filter(a => a.tanggal === todayStr).length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400 flex flex-col items-center justify-center gap-1.5">
                <AlertCircle size={20} className="text-slate-300" />
                Belum ada data check-in kehadiran terekam untuk hari ini.
              </div>
            ) : (
              <table className="w-full text-[11px] text-left">
                <thead>
                  <tr className="border-b border-slate-150 text-slate-400 uppercase tracking-wider text-[9px] font-bold font-mono">
                    <th className="py-2">KODEUNIK</th>
                    <th className="py-2">NAMA</th>
                    <th className="py-2">KATEGORI</th>
                    <th className="py-2">POSYANDU</th>
                    <th className="py-2">STATUS</th>
                    <th className="py-2 text-right">AKSI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {attendances
                    .filter(a => a.tanggal === todayStr)
                    .map((item) => (
                      <tr key={item.id} className="hover:bg-white transition-colors">
                        <td className="py-2 font-bold font-mono text-indigo-750">{item.kodeUnik}</td>
                        <td className="py-2 font-bold text-slate-805">{item.nama}</td>
                        <td className="py-2">
                          <span className="bg-slate-105 text-slate-700 px-1 py-0.5 rounded font-bold font-mono text-[9px]">
                            {item.kategori}
                          </span>
                        </td>
                        <td className="py-2 font-bold font-mono text-slate-500 text-[10px]">{item.posyandu}</td>
                        <td className="py-2">
                          <span className="bg-violet-50 text-violet-800 border border-violet-100 px-2 py-0.5 rounded text-[9px] font-bold">
                            ✔ {item.status}
                          </span>
                        </td>
                        <td className="py-2 text-right">
                          <button
                            onClick={() => onDeleteAttendance && onDeleteAttendance(item.id)}
                            className="text-red-500 hover:text-red-700 font-bold font-mono cursor-pointer"
                          >
                            Hapus
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Global info on Absen workflow */}
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 p-4 rounded-xl text-white flex items-center justify-between gap-3 shadow-md">
          <div className="space-y-1">
            <h4 className="text-[11px] font-extrabold uppercase tracking-widest font-mono text-teal-400 flex items-center gap-1">
              <Info size={11} /> Protokol Wajib Pemeriksaan
            </h4>
            <p className="text-[10px] text-slate-350 leading-relaxed font-medium">
              Sesuai aturan operasional, warga harus melakukan <b>Absensi Hadir hari ini terlebih dahulu</b> sebelum bidan desa dapat memasukkan data klinis hasil pemeriksaan pada menu tab berikutnya.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab && onNavigateToTab('input-pemeriksaan')}
            className="p-2 bg-violet-600 hover:bg-violet-500 rounded-lg text-xs font-bold shrink-0 cursor-pointer text-white flex items-center gap-1 shadow"
          >
            Meja Pemeriksaan <ArrowRight size={11} />
          </button>
        </div>

      </div>

    </div>
  );
}
