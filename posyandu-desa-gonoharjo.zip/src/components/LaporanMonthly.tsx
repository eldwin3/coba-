import React, { useState } from 'react';
import { 
  FileSpreadsheet, Calendar, FileDown, Download, CheckCircle2, ShieldAlert, BadgeAlert, Layers, RefreshCw
} from 'lucide-react';
import { Attendance, PemeriksaanBalita, PemeriksaanKategoriLain } from '../types';

interface LaporanMonthlyProps {
  attendances: Attendance[];
  pemeriksaanBalita: PemeriksaanBalita[];
  pemeriksaanLain: PemeriksaanKategoriLain[];
}

export default function LaporanMonthly({ attendances, pemeriksaanBalita, pemeriksaanLain }: LaporanMonthlyProps) {
  const [selectedMonth, setSelectedMonth] = useState('2026-05'); // Defaults to active month
  const [downloadSuccess, setDownloadSuccess] = useState('');

  // Extract date helper
  const [yearStr, monthStr] = selectedMonth.split('-');
  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const activeMonthName = monthNames[parseInt(monthStr, 10) - 1] || 'Mei';

  // Master exporter helper
  const triggerDownloadAction = (category: 'KADER' | 'BALITA' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA' | 'ABSEN') => {
    setDownloadSuccess('');
    let headers: string[] = [];
    let rows: string[][] = [];
    let fileTitle = `laporan_bulanan_${category.toLowerCase()}_${selectedMonth}`;

    if (category === 'ABSEN') {
      const filtered = attendances.filter(a => a.tanggal.startsWith(selectedMonth));
      headers = ['TANGGAL', 'NAMA', 'KODEUNIK', 'KATEGORI', 'POSYANDU', 'STATUS'];
      rows = filtered.map(a => [
        a.tanggal, a.nama, a.kodeUnik, a.kategori, a.posyandu, a.status
      ]);
    } else if (category === 'BALITA') {
      const filtered = pemeriksaanBalita.filter(b => b.tanggalInput.startsWith(selectedMonth));
      headers = [
        'TANGGAL INPUT', 'TANGGAL EDIT', 'NAMA', 'NAMA ORTU', 'POSYANDU', 'BERAT BADAN', 'TINGGI BADAN', 
        'LILA', 'LINGKAR KEPALA', 'BB/U', 'PB/TB/U', 'BB menurut PB/TB', 'STATUS N/T/2T/O', 'CATATAN', 'PENGINPUT', 'PENGEDIT'
      ];
      rows = filtered.map(b => [
        b.tanggalInput, b.tanggalEdit || '', b.nama, b.namaOrtu, b.posyandu, String(b.beratBadan), String(b.tinggiBadan),
        String(b.lila), String(b.lingkarKepala), b.bbU, b.pbTbU, b.bbPbTb, b.statusNTO, b.catatan, b.namaPenginput, b.namaPengedit || ''
      ]);
    } else {
      // Non-balita cohorts: KADER, REMAJA, IBUHAMIL, USIAPRODUKTIF, LANSIA
      const filtered = pemeriksaanLain.filter(l => l.kategori === category && l.tanggalInput.startsWith(selectedMonth));
      headers = [
        'TANGGAL INPUT', 'TANGGAL EDIT', 'NAMA', 'POSYANDU', 'BERAT BADAN', 'TINGGI BADAN', 'LINGKAR PERUT',
        'LILA', 'TEKANAN DARAH', 'GULA DARAH', 'ASAM URAT', 'KOLESTEROL', 'CATATAN', 'PENGINPUT', 'PENGEDIT'
      ];
      rows = filtered.map(l => [
        l.tanggalInput, l.tanggalEdit || '', l.nama, l.posyandu, String(l.bb), String(l.tb), String(l.lingkarPerut),
        String(l.lila), l.tekananDarah, l.gulaDarah, l.asamUrat, l.kolesterol, l.catatan, l.namaPenginput, l.namaPengedit || ''
      ]);
    }

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${fileTitle}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(`Ekstrak Laporan ${category} untuk bulan ${activeMonthName} ${yearStr} berhasil disimpan. total record: ${rows.length}.`);
    setTimeout(() => setDownloadSuccess(''), 4500);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
      
      {/* Tab Header Description */}
      <div className="flex items-center gap-3 border-b border-slate-55 pb-4">
        <div className="p-2.5 bg-violet-50 text-violet-600 rounded-xl">
          <FileSpreadsheet size={22} />
        </div>
        <div>
          <h2 className="text-base font-black text-slate-800 uppercase tracking-wide">
            Ekstraksi Laporan Otomatis Bidan & Petugas Kesehatan
          </h2>
          <p className="text-xs text-slate-400">Pilih rentang bulan untuk mengunduh laporan POSYANDU dalam format file digital secara instant</p>
        </div>
      </div>

      {/* Date filter pickers */}
      <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl max-w-md">
        <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1">
          <Calendar size={13} className="text-slate-400" />
          Tentukan Periode Laporan Bulanan (Bulan / Tahun)
        </label>
        <input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="w-full px-3.5 py-2 bg-white border border-slate-205 focus:outline-none rounded-xl text-xs font-bold font-mono text-slate-800 focus:border-violet-605"
        />
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-violet-50 border border-violet-100 rounded-xl text-violet-800 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 size={16} className="shrink-0" />
          {downloadSuccess}
        </div>
      )}

      {/* Grid containing ONLY buttons per category requested "HANYA BERISI TOMBOL SAJA TANPA BENTUK LAPORANNYA" */}
      <div className="space-y-3.5 pt-2">
        <h3 className="text-xs font-bold text-slate-450 uppercase tracking-widest font-mono">
          Pilihan Tombol Unduhan Ekstraksi Bulanan:
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          
          {/* Button 1: Balita */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-violet-205 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-violet-100 text-violet-805 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak Laporan BALITA</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Tumbuh kembang klinis BB, TB, LILA, BB/U, PB/U, status N/T/2T/O.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('BALITA')}
              className="w-full py-1.5 px-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download size={13} /> Ekstrak Balita
            </button>
          </div>

          {/* Button 2: Ibu Hamil */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-pink-200 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-pink-100 text-pink-750 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak Laporan IBU HAMIL</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Rekam klinis ANC, lingkar LILA, tensi, gula, kolesterol, komorbid bumil.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('IBUHAMIL')}
              className="w-full py-1.5 px-3 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5 shadow-sm transition"
            >
              <Download size={13} /> Ekstrak Bumil
            </button>
          </div>

          {/* Button 3: Lansia */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-slate-300 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-slate-100 text-slate-700 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak Laporan LANSIA</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Skrining tensi darah harian, asam urat, kadar kolesterol & fungsional mandiri.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('LANSIA')}
              className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download size={13} /> Ekstrak Lansia
            </button>
          </div>

          {/* Button 4: Remaja */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-blue-200 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-blue-105 text-blue-805 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak Laporan REMAJA</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Pemeriksaan Hb darah, skrining anemia, dan log pemberian tablet tambah besi.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('REMAJA')}
              className="w-full py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download size={13} /> Ekstrak Remaja
            </button>
          </div>

          {/* Button 5: Usia Produktif */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-purple-200 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-purple-100 text-purple-805 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak USIA PRODUKTIF</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Skrining berkala penyakit tidak menular (PTM) & lingkar tensi organ dewasa.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('USIAPRODUKTIF')}
              className="w-full py-1.5 px-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download size={13} /> Ekstrak Usia Prod
            </button>
          </div>

          {/* Button 6: Kader */}
          <div className="p-4 border border-slate-100 rounded-xl bg-white hover:border-amber-200 transition flex flex-col justify-between space-y-3.5">
            <div>
              <span className="text-[9px] bg-amber-100 text-amber-805 font-bold font-mono px-1.5 py-0.5 rounded">SHEET 3</span>
              <h4 className="font-extrabold text-xs text-slate-800 mt-1">Ekstrak Rekam KADER</h4>
              <p className="text-[10px] text-slate-400 leading-normal mt-0.5">Pencatatan klinis kader pelaksana tugas & keaktifan penunjang posyandu.</p>
            </div>
            <button
              onClick={() => triggerDownloadAction('KADER')}
              className="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Download size={13} /> Ekstrak Kader
            </button>
          </div>

          {/* Button 7: Full Attendance Report */}
          <div className="p-4 border border-slate-100 rounded-xl bg-slate-900 text-white transition flex flex-col justify-between space-y-3.5 col-span-1 sm:col-span-2 md:col-span-3">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <div>
                <span className="text-[9px] bg-indigo-500 text-white font-bold font-mono px-1.5 py-0.5 rounded">SHEET 2</span>
                <h4 className="font-extrabold text-xs text-white mt-1.5">Ekstrak Buku Buku Kehadiran / Absensi Bulanan (Hadir)</h4>
                <p className="text-[10px] text-slate-300 leading-normal mt-0.5">Mengompres seluruh data log kehadiran per tanggal kegiatan warga Gonoharjo ke tabel absen POSYANDU</p>
              </div>
              <span className="text-xs bg-violet-500/20 text-violet-300 px-3 py-1 rounded border border-violet-500/20 font-bold font-mono">
                {attendances.filter(a => a.tanggal.startsWith(selectedMonth)).length} Record Aktif
              </span>
            </div>
            <button
              onClick={() => triggerDownloadAction('ABSEN')}
              className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white font-black rounded-xl text-xs cursor-pointer flex items-center justify-center gap-2 shadow"
            >
              <FileDown size={14} /> Ekstrak Master Data Presensi Kehadiran Bulanan
            </button>
          </div>

        </div>
      </div>

    </div>
  );
}
