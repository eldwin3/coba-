import React, { useState } from 'react';
import { LogIn, Key, User, ShieldAlert, Eye, EyeOff, UserPlus, X, Check } from 'lucide-react';
import { LoginLog } from '../types';

interface LoginProps {
  onLoginSuccess: (username: string) => void;
  loginHistory: LoginLog[];
  onAddLoginLog: (log: LoginLog) => void;
  admins: any[];
  onRegisterAdmin?: (newAdmin: any) => void;
}

export default function Login({ onLoginSuccess, loginHistory, onAddLoginLog, admins = [], onRegisterAdmin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // States for registration modal (Sign Up)
  const [showSignUpModal, setShowSignUpModal] = useState(false);
  const [newNama, setNewNama] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPeran, setNewPeran] = useState('Kader');
  const [newBisaTambah, setNewBisaTambah] = useState(false);
  const [signUpError, setSignUpError] = useState('');
  const [signUpSuccess, setSignUpSuccess] = useState('');

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setSignUpError('');
    setSignUpSuccess('');

    const cleanName = newNama.trim();
    const cleanUser = newUsername.trim().toLowerCase();
    const cleanPass = newPassword.trim();

    if (!cleanName || !cleanUser || !cleanPass) {
      setSignUpError('Semua kolom wajib diisi!');
      return;
    }

    if (cleanUser.length < 3) {
      setSignUpError('Username minimal harus berisi 3 karakter!');
      return;
    }

    // Check if username is already taken
    const isDefaultAdmin = cleanUser === 'admin' || cleanUser === 'petugas';
    const isCustomAdmin = Array.isArray(admins) && admins.some(a => a && a.username && a.username.toString().toLowerCase() === cleanUser);

    if (isDefaultAdmin || isCustomAdmin) {
      setSignUpError('Username ini sudah terdaftar! Harap gunakan username lain.');
      return;
    }

    const newAdminObj = {
      nama: cleanName,
      username: cleanUser,
      password: cleanPass,
      peran: newPeran,
      bisaTambahMaster: newBisaTambah
    };

    if (onRegisterAdmin) {
      onRegisterAdmin(newAdminObj);
    }

    setSignUpSuccess(`Registrasi berhasil! Sekarang @${cleanUser} dapat masuk ke sistem.`);
    
    // Clear sign up fields
    setNewNama('');
    setNewUsername('');
    setNewPassword('');
    setNewPeran('Kader');
    setNewBisaTambah(false);
    
    // Auto populate credentials to let them login easily
    setUsername(cleanUser);
    setPassword(cleanPass);
    
    setTimeout(() => {
      setShowSignUpModal(false);
      setSignUpSuccess('');
    }, 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('Username dan Password wajib diisi!');
      return;
    }

    const cleanUsername = username.trim().toLowerCase();

    // Verification check against loaded admin users (and fallback default accounts)
    const matchedAdmin = Array.isArray(admins)
      ? admins.find(
          (a) =>
            a &&
            a.username &&
            a.password &&
            a.username.toString().toLowerCase() === cleanUsername &&
            a.password.toString() === password
        )
      : null;

    const isValidDefaultAdmin = cleanUsername === 'admin' && password === 'gonoharjo2026';
    const isValidDefaultPetugas = cleanUsername === 'petugas' && password === 'posyandu';

    const loginOk = !!matchedAdmin || isValidDefaultAdmin || isValidDefaultPetugas;

    const newLog: LoginLog = {
      id: `LOG-${Date.now()}`,
      username: username,
      timestamp: new Date().toLocaleString('id-ID', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      status: loginOk ? 'SUCCESS' : 'FAILED',
    };

    onAddLoginLog(newLog);

    if (loginOk) {
      onLoginSuccess(matchedAdmin ? matchedAdmin.username : cleanUsername);
    } else {
      setError('Kredensial atau Password salah! Harap periksa nama pengguna yang terdaftar.');
    }
  };

  return (
    <div id="loginPage" className="relative min-h-screen w-full flex flex-col items-center justify-start lg:justify-center py-8 lg:py-12 px-4 overflow-y-auto bg-slate-950 font-sans">
      {/* Decorative Global Background Gradient & Blur */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950"></div>
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-indigo-700 rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-purple-700 rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Main Login Portal Box */}
      <div 
        className="relative z-10 w-full max-w-5xl min-h-[600px] lg:min-h-[550px] flex flex-col lg:flex-row rounded-3xl overflow-hidden shadow-2xl bg-cover bg-center bg-no-repeat animate-fade-in"
        style={{ backgroundImage: "url('https://lh3.googleusercontent.com/d/18gy8nbDg0gCqYe3U2-n_VQ_ZizFrS_m6')" }}
      >
        {/* Seamless backdrop filter dark overlay to secure readability */}
        <div className="absolute inset-0 bg-slate-950/25 z-0"></div>

        {/* LEFT SIDE: Visual Banner */}
        <div className="w-full lg:w-5/12 relative p-8 lg:p-12 flex flex-col justify-between text-white z-10 min-h-[250px] lg:min-h-full">
          <div className="relative z-10">
            {/* Custom Vector Logo (Rasio 16:9 Transparan, Melekat Sempurna) */}
            <div className="flex items-center mb-4">
              <div className="relative w-16 h-16 rounded-full bg-white p-1 hover:scale-105 transition-transform duration-300 shadow-lg">
                <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Circle outline */}
                  <circle cx="50" cy="50" r="46" stroke="#9333ea" strokeWidth="2.5" fill="white" />
                  
                  {/* Top Orange Person */}
                  <circle cx="50" cy="27" r="5" fill="#f97316" />
                  <path d="M 34,34 Q 50,49 66,34" stroke="#f97316" strokeWidth="7" strokeLinecap="round" />

                  {/* Left Cyan Person */}
                  <circle cx="20" cy="30" r="5" fill="#06b6d4" />
                  <path d="M 33,39 Q 19,42 27,60" stroke="#06b6d4" strokeWidth="7" strokeLinecap="round" />

                  {/* Right Pink Person */}
                  <circle cx="80" cy="30" r="5" fill="#d946ef" />
                  <path d="M 67,39 Q 81,42 73,60" stroke="#d946ef" strokeWidth="7" strokeLinecap="round" />

                  {/* Bottom Green Person */}
                  <circle cx="50" cy="62" r="5" fill="#22c55e" />
                  <path d="M 34,66 Q 50,81 66,66" stroke="#22c55e" strokeWidth="7" strokeLinecap="round" />
                </svg>
              </div>
            </div>

            {/* Main Title & Subtitle */}
            <h1 className="text-4xl lg:text-5xl font-black leading-none mb-3 text-white tracking-tight drop-shadow-md">
              GO-<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-violet-300 to-indigo-300 uppercase">
                POSITIF
              </span>
            </h1>
            <span className="font-extrabold tracking-wider text-xs text-purple-100/90 font-mono uppercase bg-purple-900/40 px-2.5 py-1 rounded-md border border-purple-400/20 inline-block">
              GONOHARJO POSYANDU ILP AKTIF
            </span>
          </div>

          <div className="relative z-10 mt-6 lg:mt-10">
            <p className="text-slate-200 text-xs leading-relaxed max-w-xs font-medium mb-4 drop-shadow">
              Platform Pelayanan Kesehatan Ibu, Anak, Remaja, Usia Produktif dan Lansia Terpadu Berbasis Digital Desa Gonoharjo.
            </p>
            <div className="flex gap-1.5 mb-6">
              <span className="h-1 w-10 bg-blue-500 rounded-full"></span>
              <span className="h-1 w-3 bg-white/30 rounded-full"></span>
              <span className="h-1 w-3 bg-white/30 rounded-full"></span>
            </div>
            <div className="flex flex-wrap gap-2 text-[10px] font-bold text-slate-200 uppercase tracking-wider font-mono">
              <span className="px-2.5 py-1 rounded-md bg-black/40 border border-white/10 flex items-center gap-1.5">
                🛡 Aman
              </span>
              <span className="px-2.5 py-1 rounded-md bg-black/40 border border-white/10 flex items-center gap-1.5">
                ⚡ Cepat
              </span>
              <span className="px-2.5 py-1 rounded-md bg-black/40 border border-white/10 flex items-center gap-1.5">
                🔗 Terpadu
              </span>
            </div>
          </div>
        </div>

        {/* RIGHT SIDE: Translucent Login Input Form */}
        <div className="w-full lg:w-7/12 bg-transparent p-6 sm:p-8 lg:p-12 flex flex-col justify-center relative z-10">
          <div className="max-w-md mx-auto w-full p-4 lg:p-0">
            <div className="text-center mb-5 border-b border-white/10 pb-4">
              <h2 className="text-2xl font-black text-white tracking-tight drop-shadow-md">Administrator Portal</h2>
              <p className="text-slate-200 text-xs mt-1 font-medium drop-shadow-sm">Silakan masuk menggunakan akun Admin / Kader yang terdaftar</p>
            </div>

            {/* Login Error Notification block */}
            {error && (
              <div className="mb-5 p-3.5 bg-red-950/80 border border-red-500/40 rounded-xl flex items-start gap-3 animate-fade-in shadow-lg">
                <ShieldAlert size={18} className="text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-red-200">Akses Masuk Ditolak</h4>
                  <p className="text-[11px] text-red-300 mt-0.5 leading-relaxed font-semibold">{error}</p>
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-[10px] font-black text-slate-200 uppercase tracking-wider mb-1.5 drop-shadow-sm font-mono">
                  Username
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-300">
                    <User size={16} />
                  </span>
                  <input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className="block w-full pl-10 pr-4 py-2.5 bg-black/30 border border-white/20 focus:border-purple-400 focus:bg-black/55 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold placeholder-slate-400"
                    placeholder="Username Admin"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-200 uppercase tracking-wider mb-1.5 drop-shadow-sm font-mono">
                  Password
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-300">
                    <Key size={16} />
                  </span>
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="block w-full pl-10 pr-10 py-2.5 bg-black/30 border border-white/20 focus:border-purple-400 focus:bg-black/55 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold placeholder-slate-400"
                    placeholder="Masukkan Password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-300 hover:text-white"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div className="flex gap-2.5 pt-1">
                <button
                  type="submit"
                  className="flex-[3] py-3 px-4 bg-gradient-to-r from-violet-600 to-purple-700 hover:from-violet-700 hover:to-purple-800 text-white font-extrabold rounded-xl shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all transform active:scale-[0.98] text-xs uppercase tracking-wider flex justify-center items-center gap-2 group cursor-pointer font-mono"
                >
                  <span>MASUK SEKARANG</span>
                  <LogIn size={14} className="group-hover:translate-x-1 transition-transform shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => setShowSignUpModal(true)}
                  className="flex-[2] py-3 px-3 border border-slate-700 bg-slate-800/60 hover:bg-slate-800/95 text-slate-300 hover:text-white font-bold rounded-xl transition-all text-xs uppercase tracking-wider flex justify-center items-center gap-1.5 cursor-pointer font-mono shrink-0"
                >
                  <UserPlus size={14} className="shrink-0" />
                  <span>SIGN UP</span>
                </button>
              </div>
            </form>

            <div className="mt-6 border-t border-white/10 pt-4 text-center">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                Sistem Otorisasi Google Sheets Terpasang
              </p>
              
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="text-[10px] text-blue-400 hover:text-blue-300 hover:underline mt-2.5 inline-block cursor-pointer font-extrabold uppercase font-mono"
              >
                {showHistory ? 'Sembunyikan log aktivitas' : 'Lihat log aktivitas masuk'}
              </button>
            </div>

            {showHistory && (
              <div className="mt-4 border-t border-white/10 pt-4 animate-fade-in">
                <h3 className="text-[10px] font-black text-slate-300 font-mono mb-2 uppercase">Log Keamanan Sesi Baru:</h3>
                {loginHistory.length === 0 ? (
                  <p className="text-[10px] text-slate-500 font-mono italic">Belum ada aktivitas masuk.</p>
                ) : (
                  <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1 text-slate-300 scrollbar font-mono text-[10px]">
                    {loginHistory.slice(0, 4).map((log) => (
                      <div
                        key={log.id}
                        className={`flex justify-between items-center p-2 rounded-lg border bg-black/40 ${
                          log.status === 'SUCCESS' ? 'border-violet-500/20 text-violet-300' : 'border-red-500/20 text-red-300'
                        }`}
                      >
                        <div>
                          <span className="font-extrabold text-white">@{log.username}</span>
                          <span className="text-[9px] text-slate-400 block mt-0.5">{log.timestamp}</span>
                        </div>
                        <span className={`px-1.5 py-0.5 rounded text-[8px] font-black ${
                          log.status === 'SUCCESS' ? 'bg-violet-500/20 text-violet-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {log.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SIGN UP MODAL */}
      {showSignUpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
            {/* Close Button */}
            <button
              onClick={() => {
                setShowSignUpModal(false);
                setSignUpError('');
                setSignUpSuccess('');
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>

            {/* Header */}
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-full bg-violet-600/20 text-violet-400 flex items-center justify-center mx-auto mb-3 border border-violet-500/30">
                <UserPlus size={22} />
              </div>
              <h3 className="text-xl font-extrabold tracking-tight">Tambah Admin Baru</h3>
              <p className="text-xs text-slate-400 mt-1">Buat akun koder atau bidan untuk mengelola posyandu</p>
            </div>

            {/* Success message */}
            {signUpSuccess && (
              <div className="mb-4 p-3.5 bg-violet-950/80 border border-violet-500/40 rounded-xl flex items-start gap-3 animate-fade-in">
                <Check size={18} className="text-violet-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-violet-200">Registrasi Berhasil</h4>
                  <p className="text-[11px] text-violet-300 mt-0.5 leading-relaxed font-semibold">{signUpSuccess}</p>
                </div>
              </div>
            )}

            {/* Error message */}
            {signUpError && (
              <div className="mb-4 p-3.5 bg-red-950/80 border border-red-500/40 rounded-xl flex items-start gap-3 animate-fade-in">
                <ShieldAlert size={18} className="text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-red-100">Registrasi Gagal</h4>
                  <p className="text-[11px] text-red-200 mt-0.5 leading-relaxed font-semibold">{signUpError}</p>
                </div>
              </div>
            )}

            {/* Registration Form */}
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                  Nama Lengkap Admin
                </label>
                <input
                  type="text"
                  value={newNama}
                  onChange={(e) => setNewNama(e.target.value)}
                  placeholder="e.g. Srikandi S.ST"
                  required
                  className="block w-full px-4 py-2 bg-black/40 border border-white/20 focus:border-purple-400 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                  Username Akun
                </label>
                <input
                  type="text"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="e.g. srikandicantik"
                  required
                  className="block w-full px-4 py-2 bg-black/40 border border-white/20 focus:border-purple-400 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                  Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Password Sesi Baru"
                  required
                  className="block w-full px-4 py-2 bg-black/40 border border-white/20 focus:border-purple-400 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-wider mb-1.5 font-mono font-bold">
                    Peran / Jabatan
                  </label>
                  <select
                    value={newPeran}
                    onChange={(e) => setNewPeran(e.target.value)}
                    className="block w-full px-3 py-2 bg-slate-800 border border-white/20 focus:border-purple-400 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all font-semibold"
                  >
                    <option value="Kader">Kader Posyandu</option>
                    <option value="Bidan">Bidan Desa</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end pb-1.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={newBisaTambah}
                      onChange={(e) => setNewBisaTambah(e.target.checked)}
                      className="rounded border-white/20 text-purple-600 focus:ring-purple-500/30 w-4 h-4 bg-black/30"
                    />
                    <span className="text-[10px] font-black text-slate-300 uppercase font-mono leading-none">Bisa Tambah Master</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowSignUpModal(false);
                    setSignUpError('');
                    setSignUpSuccess('');
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-extrabold rounded-xl transition-all text-xs uppercase cursor-pointer font-mono"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:opacity-95 text-white font-extrabold rounded-xl shadow-md transition-all text-xs uppercase cursor-pointer flex items-center gap-1.5 font-mono"
                >
                  <Check size={13} />
                  <span>Daftar Sekarang</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Copyright Footer */}
      <p className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-500 text-[10px] font-black tracking-widest uppercase opacity-60 z-20 text-center w-full px-4 font-mono">
        Copyright © 2026 L. All Rights Reserved
      </p>
    </div>
  );
}
