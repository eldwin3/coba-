export interface Admin {
  username: string;
  nama: string;
  peran: 'Bidan' | 'Kader';
  password?: string;
  bisaTambahMaster?: string | boolean;
}

export interface MasterAnggota {
  kodeUnik: string; // e.g. KDR-MAW1, BLA-MIN1
  kategori: 'KADER' | 'BALITA' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA';
  nama: string;
  nik: string;
  jenisKelamin: 'L' | 'P';
  tglLahir: string;
  namaOrtu: string; // empty/blank for other categories
  posyandu: 'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN';
  alamat: string;
}

export interface Attendance {
  id: string; // unique local ID or index
  tanggal: string; // YYYY-MM-DD
  nama: string;
  kodeUnik: string;
  kategori: 'KADER' | 'BALITA' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA';
  posyandu: 'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN';
  status: 'Hadir'; // strictly Hadir per instructions
}

export interface PemeriksaanBalita {
  id: string;
  tanggalInput: string;
  tanggalEdit: string | null;
  nama: string;
  namaOrtu: string;
  posyandu: 'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN';
  beratBadan: number; // BB
  tinggiBadan: number; // TB/Panjang Badan
  lila: number; // Lingkar Lengan Atas
  lingkarKepala: number;
  bbU: 'SANGATKURANG' | 'KURANG' | 'NORMAL' | 'RESIKO BB LEBIH';
  pbTbU: 'SANGATPENDEK' | 'PENDEK' | 'NORMAL' | 'TINGGI';
  bbPbTb: 'GIZI BURUK' | 'GIZI KURANG' | 'GIZI BAIK' | 'BERISIKO GIZI LEBIH' | 'GIZI LEBIH' | 'OBESITAS';
  statusNTO: 'N' | 'T' | '2T' | 'O';
  catatan: string;
  namaPenginput: string;
  namaPengedit: string | null;
}

export interface PemeriksaanKategoriLain {
  id: string;
  tanggalInput: string;
  tanggalEdit: string | null;
  nama: string;
  kategori: 'KADER' | 'REMAJA' | 'IBUHAMIL' | 'USIAPRODUKTIF' | 'LANSIA';
  posyandu: 'MINERAL 1' | 'MINERAL 2' | 'MAWAR' | 'SEJAHTERA' | 'PROTEIN' | 'VITAMIN';
  bb: number;
  tb: number;
  lingkarPerut: number;
  lila: number;
  tekananDarah: string;     // can be HABIS or ALATKOSONG
  gulaDarah: string;        // can be HABIS or ALATKOSONG
  asamUrat: string;         // can be HABIS or ALATKOSONG
  kolesterol: string;       // can be HABIS or ALATKOSONG
  catatan: string;
  namaPenginput: string;
  namaPengedit: string | null;
}

export interface LoginLog {
  id: string;
  username: string;
  timestamp: string;
  status: 'SUCCESS' | 'FAILED';
}

export interface SyncConfig {
  appsScriptUrl: string;
  lastSyncedAt: string | null;
  autoSync: boolean;
}
